var canvas = document.getElementById('myCanvas');// 画布
var context = canvas.getContext('2d');

var change = document.getElementById('change');// 模板
var change1 = document.getElementById('change1');// 微信支付
var change2 = document.getElementById('change2');// 支付宝支付
var change3 = document.getElementById('change3');// 微信添加

var change4 = document.getElementById('change4');// 微信添加2

var download = document.getElementById('download');
var btn = document.getElementById('btn');

var img = new Image();
var img1 = new Image();
var img2 = new Image();
var img3 = new Image();
var img4 = new Image();

// 当前模板参数
var dataval;

// 处理跨域
img.crossOrigin = 'Anonymous';
img1.crossOrigin = 'Anonymous';
img2.crossOrigin = 'Anonymous';
img3.crossOrigin = 'Anonymous';
img4.crossOrigin = 'Anonymous';

// 获取的url
var newurl = "";

// 定时器
var setin;
var feww;

var arr = [];

$("#change").click(function(){
	if($(this).val()!="") { 
		alert("已选择文件,修改请点击重置!");
		return false; 
	} 
})

$("#change1").click(function(){
    if($(this).val()!="") { 
		alert("已选择文件,修改请点击重置!");
		return false; 
	} 
})

$("#change2").click(function(){
    if($(this).val()!="") { 
		alert("已选择文件,修改请点击重置!");
		return false; 
	} 
})

$("#change3").click(function(){
    if($(this).val()!="") { 
		alert("已选择文件,修改请点击重置!");
		return false; 
	} 
})

$("#change4").click(function(){
   if($(this).val()!="") { 
		alert("已选择文件,修改请点击重置!");
		return false; 
	} 
})

// 撤销
function undo(){
	context = arr[arr.length-2];
}

// 模板
change.onchange = function(event) {
    var file = event.target.files[0];
    var filename = event.target.value;
    getErweima(filename);
    if (filename.indexOf("big") > 0) {
        canvas.width = 1200;
        canvas.height = 469;
    } else if (filename.indexOf("small") > 0) {
        canvas.width = 1100;
        canvas.height = 430;
    } else {
        alert("请正确选择模板!");
        return;
    }
    var url = window.URL.createObjectURL(file);
    img.src = url;
}

// 微信支付
change1.onchange = function(event) {
    createErweima("change1","qrcodeCanvas");
    setin = setInterval(function() {
        $("#qrcodeCanvas").children().attr("id", "dsds");
        if (document.getElementById("dsds") != null && typeof (document.getElementById("dsds")) != "undefined") {
            clearInterval(setin);
            img1.src = document.getElementById("dsds").toDataURL("image/png");
        }
    }, 10);
}

// 支付宝支付
change2.onchange = function(event) {
    createErweima("change2","qrcodeCanvas2");
    setin = setInterval(function() {
        $("#qrcodeCanvas2").children().attr("id", "dsds2");
        if (document.getElementById("dsds2") != null && typeof (document.getElementById("dsds2")) != "undefined") {
            clearInterval(setin);
            img2.src = document.getElementById("dsds2").toDataURL("image/png");
        }
    }, 10);
}

// 微信添加
change3.onchange = function(event) {
    createErweima("change3","qrcodeCanvas3");
    setin = setInterval(function() {
        $("#qrcodeCanvas3").children().attr("id", "dsds3");
        if (document.getElementById("dsds3") != null && typeof (document.getElementById("dsds3")) != "undefined") {
            clearInterval(setin);
            img3.src = document.getElementById("dsds3").toDataURL("image/png");
        }
    }, 10);
}

// 微信添加2
change4.onchange = function(event) {
    createErweima("change4","qrcodeCanvas4");
    setin = setInterval(function() {
        $("#qrcodeCanvas4").children().attr("id", "dsds4");
        if (document.getElementById("dsds4") != null && typeof (document.getElementById("dsds4")) != "undefined") {
            clearInterval(setin);
            img4.src = document.getElementById("dsds4").toDataURL("image/png");
        }
    }, 10);
}

// 模板文件
img.onload = function() {
    context.drawImage(img, 0, 0, dataval.muban.width, dataval.muban.height);context.save();
    context.save();
}

// 微信支付
img1.onload = function() {
    context.drawImage(img1, dataval.weixin.x, dataval.weixin.y, dataval.weixin.width, dataval.weixin.height);

    var logo = new Image();
    logo.src = "img/weixin.png";
    logo.onload = function() {
        var xindex = dataval.weixin.x + (dataval.weixin.width / 2) - 25;
        var yindex = dataval.weixin.y + (dataval.weixin.height / 2) - 25;
        context.drawImage(logo, xindex, yindex, 50, 50);

        $("#qrcodeCanvas").empty();		
    }
}

// 支付宝支付
img2.onload = function() {
    context.drawImage(img2, dataval.zhifubao.x, dataval.zhifubao.y, dataval.zhifubao.width, dataval.zhifubao.height);

    var logo = new Image();
    logo.src = "img/zhifubao.png";
    logo.onload = function() {
        var xindex = dataval.zhifubao.x + (dataval.zhifubao.width / 2) - 25;
        var yindex = dataval.zhifubao.y + (dataval.zhifubao.height / 2) - 25;
        context.drawImage(logo, xindex, yindex, 50, 50);

        $("#qrcodeCanvas2").empty();	
    }
}

// 微信添加
img3.onload = function() {
    context
            .drawImage(img3, dataval.addweixin.x, dataval.addweixin.y, dataval.addweixin.width,
                    dataval.addweixin.height);
    var logo = new Image();
    logo.src = "img/weixin.png";
    logo.onload = function() {
        var xindex = dataval.addweixin.x + (dataval.addweixin.width / 2) - 25;
        var yindex = dataval.addweixin.y + (dataval.addweixin.height / 2) - 25;
        context.drawImage(logo, xindex, yindex, 50, 50);

        $("#qrcodeCanvas3").empty();	
    }
}

// 微信添加2
img4.onload = function() {
    context.drawImage(img4, dataval.addweixintwo.x, dataval.addweixintwo.y, dataval.addweixintwo.width,
            dataval.addweixintwo.height);
    var logo = new Image();
    logo.src = "img/weixin.png";
    logo.onload = function() {
        var xindex = dataval.addweixintwo.x + (dataval.addweixintwo.width / 2) - 25;
        var yindex = dataval.addweixintwo.y + (dataval.addweixintwo.height / 2) - 25;
        context.drawImage(logo, xindex, yindex, 50, 50);

        $("#qrcodeCanvas4").empty();	
    }
}

// 获取预览图片路径
var getObjectURL = function(file) {
    var url = null;
    if (window.createObjectURL != undefined) { // basic
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { // mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

// 创建二维码
function createErweima(id,canvasCode) {
	
    var newfile = document.getElementById(id).files[0];
	
	// 调用函数处理图片 　　　　　　　　　　　　　　　　
	dealImage(window.URL.createObjectURL(newfile), {
	// 注意：在pc端可以用绝对路径或相对路径，移动端最好用绝对路径（因为用take photo后的图片路径，我没有试成功（如果有人试成功了可以分享一下经验））
	 width : 200
	}, function(base){
		// console.log("压缩后：" + base.length / 1024 + " " + base);　　　
		getUrlWay(base.replace("data:image/png;base64,",""));　
	});

	/*var reader = new FileReader();
    reader.onload = (function (file) {
        return function (e) {
           // console.info(this.result); //这个就是base64的数据了 
		   getUrlWay(this.result.replace("data:image/png;base64,",""));
        };
    })(newfile);
    reader.readAsDataURL(newfile);*/
	
	feww = setInterval(function() {
        if (newurl != "") {
            clearInterval(feww);
            console.log("url：", newurl);
			var flag = true;
			var alertimg = "请选择正确二维码!";

			if (flag) {
				/*$("#qrcodeCanvas").empty();
				$("#qrcodeCanvas2").empty();
				$("#qrcodeCanvas3").empty();
				$("#qrcodeCanvas4").empty();*/

				$("#"+ canvasCode).qrcode({
					render : "canvas",
					text : newurl,
					width : "500", // 二维码的宽度
					height : "500", // 二维码的高度
					background : "#ffffff", // 二维码的后景色
					foreground : "#000000" // 二维码的前景色
				});
			} else {
				clearInterval(setin);
				alert(alertimg);
			}
        }
    }, 10);
}

// 确认店铺名
function trueshopname() {
    var shopname = $("#shopname").val();
    context.font = "bold " + dataval.shopname.size + "px " + $("#shopface").val();
    context.fillStyle = "#000";
    context.textAlign = "center";
    context.fillText(shopname, dataval.shopname.x, dataval.shopname.y);

    arr.push(context);
}

// 确认wifi
function truewifi() {
    var wifiname = $("#wifiname").val();
    var wifipassword = $("#wifipassword").val();

    context.font = "bold " + dataval.wifi.size + "px " + $("#wififace").val();
    context.fillStyle = "#000";
    context.fillText(wifiname, dataval.wifi.x, dataval.wifi.y);

    context.font = "bold " + dataval.wifi.size + "px " + $("#wififace").val();
    context.fillStyle = "#000";
    context.fillText(wifipassword, dataval.wifi.x, dataval.wifi.y + 36);
}

// 获取模板中的二维码数量,类型,位置
function getErweima(name) {
    getDataVal(getFileName(name));
}

// 获取文件名称
function getFileName(path) {
    var pos1 = path.lastIndexOf('/');
    var pos2 = path.lastIndexOf('\\');
    var pos = Math.max(pos1, pos2);
    if (pos < 0) {
        return path.replace(".png", "");
    } else {
        return path.substring(pos + 1).replace(".png", "");
    }
}

function getUrlWay(imgData){	
	$.ajax({
		type: 'post',
		url: 'http://route.showapi.com/887-4',
		dataType: 'json',
		async : false,
		data: {
			"showapi_timestamp": formatterDateTime(),
			"showapi_appid": '68659', //这里需要改成自己的appid
			"showapi_sign": 'b1cb28ab427f4e39ad50c63a76302b0d',  //这里需要改成自己的应用的密钥secret
			"imgData": imgData,
			"handleImg":"0"
		},
		error: function(XmlHttpRequest, textStatus, errorThrown) {
			alert("操作失败!");
		},
		success: function(result) {
			// console.log(result) //console变量在ie低版本下不能用
			if(result.showapi_res_body.ret_code == "0"){
				newurl = result.showapi_res_body.retText;
			}else{
				newurl = "";
				clearInterval(feww);
				clearInterval(setin);
				alert(result.showapi_res_body.msg);
			}
		}
	});
}

function formatterDateTime() {
	  var date=new Date();
	  var month=date.getMonth() + 1;
	  var datetime = date.getFullYear()
			+ ""// "年"
			+ (month >= 10 ? month : "0"+ month)
			+ ""// "月"
			+ (date.getDate() < 10 ? "0" + date.getDate() : date
					.getDate())
			+ ""
			+ (date.getHours() < 10 ? "0" + date.getHours() : date
					.getHours())
			+ ""
			+ (date.getMinutes() < 10 ? "0" + date.getMinutes() : date
					.getMinutes())
			+ ""
			+ (date.getSeconds() < 10 ? "0" + date.getSeconds() : date
					.getSeconds());
	return datetime;
}

/**
 * 图片压缩，默认同比例压缩
 * @param {Object} path 
 *   pc端传入的路径可以为相对路径，但是在移动端上必须传入的路径是照相图片储存的绝对路径
 * @param {Object} obj
 *   obj 对象 有 width， height， quality(0-1)
 * @param {Object} callback
 *   回调函数有一个参数，base64的字符串数据
 */
function dealImage(path, obj, callback){
	 var img = new Image();
	 img.src = path;
	 img.onload = function(){
		  var that = this;
		  // 默认按比例压缩
		  var w = that.width,
		   h = that.height,
		   scale = w / h;
		   w = obj.width || w;
		   h = obj.height || (w / scale);
		  var quality = 0.7;  // 默认图片质量为0.7
		  //生成canvas
		  var canvas = document.createElement('canvas');
		  var ctx = canvas.getContext('2d');
		  // 创建属性节点
		  var anw = document.createAttribute("width");
		  anw.nodeValue = w;
		  var anh = document.createAttribute("height");
		  anh.nodeValue = h;
		  canvas.setAttributeNode(anw);
		  canvas.setAttributeNode(anh); 
		  ctx.drawImage(that, 0, 0, w, h);
		  // 图像质量
		  if(obj.quality && obj.quality <= 1 && obj.quality > 0){
		   quality = obj.quality;
		  }
		  // quality值越小，所绘制出的图像越模糊
		  var base64 = canvas.toDataURL('image/jpeg', quality );
		  // 回调函数返回base64的值
		  callback(base64);
	 }
}
/* ----------------------------------以下弃用 ------------------------------- */
btn.onclick = function() {
    var img = convertCanvasToImage(canvas)
    var arr = img.src.split(',')
    var mime = arr[0].match(/:(.*?);/)[1]
    var bstr = atob(arr[1])
    var n = bstr.length
    var u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    var blob = new Blob([ u8arr ], {
        type : mime
    })

}

download.onclick = function(blob) {
    var img = convertCanvasToImage(canvas)
    download.href = img.src
}

function convertCanvasToImage(canvas) {
    var newimage = new Image();
    newimage.crossOrigin = 'Anonymous';
    newimage.src = canvas.toDataURL("image/png");
    return newimage;
}