// 数据集
function getDataVal(key) {
    var objArr = [];
    var obj = {};
    /*---------------1不加_big------------------*/
    obj.key = "1不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 765,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 200,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*----------------1加店名_big-----------------*/
    obj = {};
    obj.key = "1加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 765,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 200,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------2不加_big------------------*/
    obj = {};
    obj.key = "2不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 110,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 490,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 870,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------2加店名_big------------------*/
    obj = {};
    obj.key = "2加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 110,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 490,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 870,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------3不加_big------------------*/
    obj = {};
    obj.key = "3不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 120,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 880,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------3加店名_big------------------*/
    obj = {};
    obj.key = "3加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 120,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 880,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 620,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------4不加_big------------------*/
    obj = {};
    obj.key = "4不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 335,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 635,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------4加店名_big------------------*/
    obj = {};
    obj.key = "4加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 335,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 635,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------5不加_big------------------*/
    obj = {};
    obj.key = "5不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 460,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 830,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------5加店名_big------------------*/
    obj = {};
    obj.key = "5加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 460,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 830,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------6不加_big------------------*/
    obj = {};
    obj.key = "6不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 340,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 635,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------6加店名_big------------------*/
    obj = {};
    obj.key = "6加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 345,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 640,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------7不加_big------------------*/
    obj = {};
    obj.key = "7不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 70,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 460,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 950,
        "y" : 375
    };
    objArr.push(obj);
    /*---------------7加店名_big------------------*/
    obj = {};
    obj.key = "7加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 75,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 470,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 964,
        "y" : 385
    };
    objArr.push(obj);
    /*---------------8不加_big------------------*/
    obj = {};
    obj.key = "8不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 30,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 320,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 615,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 970,
        "y" : 383
    };
    objArr.push(obj);
    /*---------------8加店名_big------------------*/
    obj = {};
    obj.key = "8加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 30,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 320,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 615,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 972,
        "y" : 387
    };
    objArr.push(obj);
    /*---------------9不加_big------------------*/
    obj = {};
    obj.key = "9不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 150,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 845,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------9加店名_big------------------*/
    obj = {};
    obj.key = "9加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 150,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 845,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 620,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------10不加_big------------------*/
    obj = {};
    obj.key = "10不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 340,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 635,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------10加店名_big------------------*/
    obj = {};
    obj.key = "10加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 345,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 640,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------13不加_big------------------*/
    obj = {};
    obj.key = "13不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 90,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 870,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------13加店名_big------------------*/
    obj = {};
    obj.key = "13加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 90,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 860,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 620,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------14不加_big------------------*/
    obj = {};
    obj.key = "14不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 340,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 635,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------14加店名_big------------------*/
    obj = {};
    obj.key = "14加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 345,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 640,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------15不加_big------------------*/
    obj = {};
    obj.key = "15不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 110,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 460,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------15加店名_big------------------*/
    obj = {};
    obj.key = "15加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 100,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 470,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------16不加_big------------------*/
    obj = {};
    obj.key = "16不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 40,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 330,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 625,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 970,
        "y" : 383
    };
    objArr.push(obj);
    /*---------------16加店名_big------------------*/
    obj = {};
    obj.key = "16加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 40,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 330,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 625,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 972,
        "y" : 387
    };
    objArr.push(obj);
    /*---------------中间LG不加_big------------------*/
    obj = {};
    obj.key = "中间LG不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 80,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 880,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------中间LG加店名_big------------------*/
    obj = {};
    obj.key = "中间LG加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 80,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 880,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 620,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------左LG不加_big------------------*/
    obj = {};
    obj.key = "左LG不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 325,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 625,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------左LG加店名_big------------------*/
    obj = {};
    obj.key = "左LG加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 325,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 625,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 930,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 600,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------------------------*/

    /*----------------------------------------------以上为大板数据---------------------------------*/

    /*---------------1不加_small------------------*/
    obj = {};
    obj.key = "1不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 185,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 740,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------1加店名_small------------------*/
    obj = {};
    obj.key = "1加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 185,
        "y" : 145,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 740,
        "y" : 145,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 580,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------2不加_small------------------*/
    obj = {};
    obj.key = "2不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 50,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 410,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 790,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------2加店名_small------------------*/
    obj = {};
    obj.key = "2加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 50,
        "y" : 145,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 410,
        "y" : 145,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 790,
        "y" : 145,
        "width" : 240,
        "height" : 240
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 550,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------3不加_small------------------*/
    obj = {};
    obj.key = "3不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 70,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 780,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------3加店名_small------------------*/
    obj = {};
    obj.key = "3加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 70,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 780,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 530,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------5不加_small------------------*/
    obj = {};
    obj.key = "5不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 420,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 780,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------5加店名_small------------------*/
    obj = {};
    obj.key = "5加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 420,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 780,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 530,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------7不加_small------------------*/
    obj = {};
    obj.key = "7不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 70,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 390,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 860,
        "y" : 350
    };
    objArr.push(obj);
    /*---------------7加店名_small------------------*/
    obj = {};
    obj.key = "7加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 70,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 390,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 530,
        "y" : 50
    };
    obj.wifi = {
        "size" : 26,
        "face" : $("#wififace").val(),
        "x" : 880,
        "y" : 350
    };
    objArr.push(obj);

    /*---------------9不加_small------------------*/
    obj = {};
    obj.key = "9不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 80,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------9加店名_small------------------*/
    obj = {};
    obj.key = "9加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 80,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 550,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------13不加_small------------------*/
    obj = {};
    obj.key = "13不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 80,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------13加店名_small------------------*/
    obj = {};
    obj.key = "13加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 80,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 550,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------15不加_small------------------*/
    obj = {};
    obj.key = "15不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 90,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 440,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------15加店名_small------------------*/
    obj = {};
    obj.key = "15加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 90,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 440,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 550,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------中间LG不加_small------------------*/
    obj = {};
    obj.key = "中间LG不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 90,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------中间LG加店名_small------------------*/
    obj = {};
    obj.key = "中间LG加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 90,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 550,
        "y" : 55
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);

    /*---------------左LG不加_small------------------*/
    obj = {};
    obj.key = "左LG不加_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 490,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 130,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------左LG加店名_small------------------*/
    obj = {};
    obj.key = "左LG加店名_small";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1100,
        "height" : 430
    };
    obj.weixin = {
        "x" : 490,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.zhifubao = {
        "x" : 790,
        "y" : 150,
        "width" : 240,
        "height" : 240
    };
    obj.addweixin = {
        "x" : 0,
        "y" : 0,
        "width" : 0,
        "height" : 0
    };
    obj.shopname = {
        "size" : 50,
        "face" : $("#shopface").val(),
        "x" : 530,
        "y" : 50
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------------------------*/

    /*----------------------------------------------以上为小板数据---------------------------------*/

    /*---------------18不加_big------------------*/
    obj = {};
    obj.key = "18不加_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 30,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 325,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 610,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.addweixintwo = {
        "x" : 900,
        "y" : 165,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 0,
        "face" : $("#shopface").val(),
        "x" : 0,
        "y" : 0
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------18加店名_big------------------*/
    obj = {};
    obj.key = "18加店名_big";
    obj.muban = {
        "x" : 0,
        "y" : 0,
        "width" : 1200,
        "height" : 469
    };
    obj.weixin = {
        "x" : 30,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.zhifubao = {
        "x" : 325,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixin = {
        "x" : 610,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.addweixintwo = {
        "x" : 900,
        "y" : 175,
        "width" : 250,
        "height" : 250
    };
    obj.shopname = {
        "size" : 60,
        "face" : $("#shopface").val(),
        "x" : 620,
        "y" : 60
    };
    obj.wifi = {
        "size" : 0,
        "face" : $("#wififace").val(),
        "x" : 0,
        "y" : 0
    };
    objArr.push(obj);
    /*---------------------------------*/
    var flag = true;
    $.each(objArr, function(index, obj) {
        if (obj.key == key) {
            flag = false;
            dataval = obj;
        }
    });
    /*if (flag) {
        alert("无相应模板参数!");
    }*/
}