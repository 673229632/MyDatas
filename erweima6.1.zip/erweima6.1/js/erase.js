var erase = function (id){
	var canvas = document.getElementById(id);
	var ctx=canvas.getContext('2d');

    var locationstart;
    var locationend;

    function eventDown(e){
        e.preventDefault();
        locationstart = getLocation(e.clientX, e.clientY);
    }

    function eventUp(e){
        e.preventDefault();
        locationend = getLocation(e.clientX, e.clientY);
        ctx.fillStyle  = "#fff";
        ctx.beginPath();
        ctx.fillRect(locationstart.x,locationstart.y,(locationend.x - locationstart.x),(locationend.y - locationstart.y));
        ctx.fill();
        // ctx.clearRect(locationstart.x,locationstart.y,(locationend.x - locationstart.x),(locationend.y - locationstart.y));
    }

    function getLocation(x, y) {
        var bbox = canvas.getBoundingClientRect();
        return {
            x: (x - bbox.left) * (canvas.width / bbox.width),
            y: (y - bbox.top) * (canvas.height / bbox.height)
            
            /*
             * 此处不用下面两行是为了防止使用CSS和JS改变了canvas的高宽之后是表面积拉大而实际
             * 显示像素不变而造成的坐标获取不准的情况
            x: (x - bbox.left),
            y: (y - bbox.top)
            */
        };
    }
    
    canvas.addEventListener('touchstart', eventDown);
    canvas.addEventListener('touchend', eventUp);
    
    canvas.addEventListener('mousedown', eventDown);
    canvas.addEventListener('mouseup', eventUp);
    
	 
}
