-- 数据初始化
INSERT INTO t_goods_banner VALUES ('92b95164f92311e8ba48f832e41b24cd', '首页置顶', '首页轮播图', null, now(), null, now(),'0');