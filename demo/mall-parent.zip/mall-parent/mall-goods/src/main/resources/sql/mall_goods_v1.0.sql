
-- banner表
CREATE TABLE t_goods_banner (
  id varchar(32) PRIMARY KEY,
  name varchar(50) DEFAULT NULL COMMENT 'Banner名称，通常作为标识',
  description varchar(255) DEFAULT NULL COMMENT 'Banner描述',
  create_by varchar(32),
  create_at timestamp(6),
  update_by varchar(32),
  updated_at timestamp(6),
  corp_code varchar(50)
)COMMENT='banner管理表';

-- banner 附属表
CREATE TABLE t_goods_banner_item (
  id varchar(32) primary key,
  image_id varchar(32) NOT NULL COMMENT '外键，关联image表',
  key_word varchar(100) NOT NULL COMMENT '执行关键字，根据不同的type含义不同',
  type tinyint(4) NOT NULL DEFAULT '1' COMMENT '跳转类型，可能导向商品，可能导向专题，可能导向其他。0，无导向；1：导向商品;2:导向专题',
  banner_id varchar(32) NOT NULL COMMENT '外键，关联banner表',
  create_by varchar(32),
  create_at timestamp(6),
  update_by varchar(32),
  updated_at timestamp(6),
  corp_code varchar(50)
)COMMENT='banner子项表';



