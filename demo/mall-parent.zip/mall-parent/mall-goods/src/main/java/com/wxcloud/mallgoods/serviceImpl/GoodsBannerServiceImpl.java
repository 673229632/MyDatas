package com.wxcloud.mallgoods.serviceImpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wxcloud.mallgoods.entity.GoodsBanner;
import com.wxcloud.mallgoods.mapper.GoodsBannerMapper;
import com.wxcloud.mallgoods.service.IGoodsBannerService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class GoodsBannerServiceImpl extends ServiceImpl<GoodsBannerMapper, GoodsBanner> implements IGoodsBannerService {
    @Override
    public List<GoodsBanner> getGoodsBannerList() {
        return this.baseMapper.getGoodsBannerList();
    }
}
