package com.wxcloud.mallgoods.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.wxcloud.mall.mallmybatisplus.base.BaseModel;

@TableName(value = "t_goods_banner")
public class GoodsBanner extends BaseModel {

    private String name;

    private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
