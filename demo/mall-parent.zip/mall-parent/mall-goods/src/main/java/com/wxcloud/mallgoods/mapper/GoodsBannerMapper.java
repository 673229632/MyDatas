package com.wxcloud.mallgoods.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wxcloud.mallgoods.entity.GoodsBanner;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface GoodsBannerMapper extends BaseMapper<GoodsBanner> {

    @Select("getGoodsBannerList")
    List<GoodsBanner> getGoodsBannerList();
}
