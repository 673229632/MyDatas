package com.wxcloud.mallgoods.controller;


import com.wxcloud.mallgoods.entity.GoodsBanner;
import com.wxcloud.mallgoods.service.IGoodsBannerService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/banner")
public class GoodsBannerController {

    @Resource
    private IGoodsBannerService goodsBannerService;

    @RequestMapping(value = "/index")
    public String demo() {
        List<GoodsBanner> goodsBannerList = goodsBannerService.getGoodsBannerList();
        return "123";
    }
}
