package com.wxcloud.mallgoods;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class MallGoodsApplicationTests {

//    @Test
//    public void contextLoads() {
//    }

}
