package com.wxcloud.mall.mallmybatisplus.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.wxcloud.mall.mallmybatisplus.base.BaseModel;
import com.wxcloud.mallcommon.context.CommonContext;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 数据插入拦截器
 */
@Component
public class MetaObjectHandlerConfig implements MetaObjectHandler {

    /**
     * 新增数据：参数值存在则跳过
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        //创建时间
        Object createAt = metaObject.getValue(BaseModel.CREATED_AT);
        if (null == createAt) {
            metaObject.setValue(BaseModel.CREATED_AT, LocalDateTime.now());
        }
        //创建人
        Object createBy = metaObject.getValue(BaseModel.CREATE_BY);
        if (null == createBy) {
            metaObject.setValue(BaseModel.CREATE_BY, CommonContext.getUserId());
        }
    }

    /**
     * 修改数据：参数值存在则跳过
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        Object updateBy = getFieldValByName(BaseModel.UPDATE_BY, metaObject);
        if (null == updateBy) {
            setFieldValByName(BaseModel.UPDATE_BY, CommonContext.getUserId(), metaObject);
        }
        Object updatedAt = getFieldValByName(BaseModel.UPDATED_AT, metaObject);
        if (null == updatedAt) {
            setFieldValByName(BaseModel.UPDATED_AT, LocalDateTime.now(), metaObject);
        }
    }
}
