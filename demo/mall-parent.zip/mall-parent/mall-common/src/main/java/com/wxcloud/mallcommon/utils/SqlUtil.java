package com.wxcloud.mallcommon.utils;

/**
 * 模糊查询时候，需要对参数转义下
 *
 * @author zhangna
 * @since 2018/4/10
 */
public class SqlUtil {
    public SqlUtil() {
    }

    public static String escapeLike(String value) {
        if (value == null) {
            return null;
        }

        value = value.replace("%", "\\%");
        value = value.replace("_", "\\_");

        return value;
    }

    public static String asLike(String value) {
        String trim = value.trim();
        trim = "%" + trim + "%";
        return trim;
    }
}