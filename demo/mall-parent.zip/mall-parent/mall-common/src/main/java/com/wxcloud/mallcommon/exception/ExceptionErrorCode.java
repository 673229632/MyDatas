package com.wxcloud.mallcommon.exception;

/**
 * 异常{@link ExceptionErrorCode}的异常编码
 */
public enum ExceptionErrorCode {
    /**
     * 参数非法
     */
    ILLEGAL_PARAM,
    /**
     * 授权token需刷新
     */
    AUTH_TOKEN_NEED_REFRESH,
    /**
     * 系统异常
     */
    SYSTEM_ERROR,
    /**
     * 数据已存在
     */
    DATA_ALREADY_EXIST,
    /**
     * 数据不存在
     */
    DATA_NOT_EXIST
}
