package com.wxcloud.mallcommon.exception;


import org.apache.commons.lang3.StringUtils;

/**
 * UnAuthorizedException
 */
public class UnAuthorizedException extends RuntimeException {

    private final ExceptionErrorCode errorCode;

    public UnAuthorizedException(ExceptionErrorCode errorCode) {
        this(errorCode, null, null);
    }

    public UnAuthorizedException(ExceptionErrorCode errorCode, Throwable cause) {
        this(errorCode, null, cause);
    }

    public UnAuthorizedException(ExceptionErrorCode errorCode, String message) {
        this(errorCode, message, null);
    }

    public UnAuthorizedException(ExceptionErrorCode errorCode, String message, Throwable cause) {
        super(StringUtils.defaultString(message), cause);

        this.errorCode = errorCode;
    }

    public ExceptionErrorCode getErrorCode() {
        return errorCode;
    }

}