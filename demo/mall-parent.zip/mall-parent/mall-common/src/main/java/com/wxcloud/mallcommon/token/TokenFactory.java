package com.wxcloud.mallcommon.token;

import com.wxcloud.mallcommon.exception.ExceptionErrorCode;
import com.wxcloud.mallcommon.exception.UnAuthorizedException;
import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * token工厂，进行token生成和解密
 */
@Component
public class TokenFactory {

    private static TokenProperties tokenProperties;

    @Resource
    public void setTokenProperties(TokenProperties tokenProperties) {
        TokenFactory.tokenProperties = tokenProperties;
    }

    public static String getTokenByUser(String id, String employeeCode, String userName) {

        Map<String, Object> map = new HashMap<>(3);
        map.put("userId", id);
        map.put("employeeCode", employeeCode);
        map.put("userName", userName);

        return createToken(map);
    }

    public static String createToken(Map<String, Object> map) {
        //过期时间
        long currentTime = System.currentTimeMillis();
        Long mills = currentTime + tokenProperties.getExpireTime();
        Date expireTime = new Date(mills);
        map.put("expireTime", mills);
        // 刷新时间，当过期时间到时，刷新token，当刷新时间过期时，则token过期
        Date refreshTime = new Date(currentTime + tokenProperties.getRefreshTime());
        map.put("refreshTime", refreshTime.getTime());

        JwtBuilder builder = Jwts.builder().setClaims(map).setExpiration(expireTime)
                .signWith(SignatureAlgorithm.HS512, tokenProperties.getSecretKey());
        String jwt = builder.compact();

        return tokenProperties.getHeaderPrefix() + jwt;
    }

    public static Map<String, Object> validateToken(String token) {
        Claims claims = null;
        try {
            claims = Jwts.parser().setSigningKey(tokenProperties.getSecretKey())
                    .parseClaimsJws(token.replace(tokenProperties.getHeaderPrefix(), "")).getBody();
        } catch (ExpiredJwtException e) {
            //token过期异常
            claims = e.getClaims();
            Long refreshMills = (Long) claims.get("refreshTime");
            Date refreshDate = new Date(refreshMills);
            if (refreshDate.compareTo(new Date()) >= 0) {
                token = createToken(claims);
                throw new UnAuthorizedException(ExceptionErrorCode.AUTH_TOKEN_NEED_REFRESH, token, e);
            }

        } catch (JwtException e) {
            throw new IllegalStateException("Expire Token. " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalStateException("Invalid Token. " + e.getMessage());
        }

        return claims;
    }
}
