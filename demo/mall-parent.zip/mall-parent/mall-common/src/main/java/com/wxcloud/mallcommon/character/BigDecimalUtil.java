package com.wxcloud.mallcommon.character;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * 大数操作工具类
 */
public class BigDecimalUtil {

    /**
     * 这个方法将传入的大实数按标度为2，舍入模式为四舍五入处理并返回处理后的十进制数
     *
     * @param bigDecimal 需要处理的实数
     */
    public static BigDecimal scale(BigDecimal bigDecimal) {
        return bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * 把两个BigDecimal数相加，返回相加后的结果。
     * 如果参数a或b其中一个为null，则返回另一个参数的值。两个参数都为null，则返回BigDecimal.ZERO。
     *
     * @param a 参数
     * @param b 参数
     * @return 返回相加后的结果
     */
    public static BigDecimal add(BigDecimal a, BigDecimal b) {
        BigDecimal result = BigDecimal.ZERO;
        if (a != null) {
            result = result.add(a);
        }
        if (b != null) {
            result = result.add(b);
        }
        return result;
    }

    /**
     * 把两个BigDecimal类型的参数a 和 b相减，返回 a-b 相减后的结果。
     * 如果参数a为null，则返回b的负值；如果b为null，则返回a。两个参数都为null，则返回BigDecimal.ZERO。
     *
     * @param a 参数
     * @param b 参数
     * @return 返回相加后的结果
     */
    public static BigDecimal subtract(BigDecimal a, BigDecimal b) {
        if (a == null && b == null) {
            return BigDecimal.ZERO;
        }

        if (a == null) {
            return BigDecimal.ZERO.subtract(b);
        }

        if (b == null) {
            return a;
        }

        return a.subtract(b);
    }


    /**
     * 把两个BigDecimal类型的参数a 和 b想乘，返回 a*b 相乘后的结果。
     * 两个参数都为null，则返回BigDecimal.ZERO。
     *
     * @param a 参数
     * @param b 参数
     * @return 返回相乘后的结果
     */
    public static BigDecimal multiply(BigDecimal a, BigDecimal b) {
        if (a == null || b == null) {
            return BigDecimal.ZERO;
        }

        return a.multiply(b);
    }

    public static BigDecimal multiply(BigDecimal a, Integer b) {
        if (a == null || b == null) {
            return BigDecimal.ZERO;
        }

        return a.multiply(new BigDecimal(b));
    }

    public static BigDecimal multiply(BigDecimal a, Double b) {
        if (a == null || b == null) {
            return BigDecimal.ZERO;
        }

        return a.multiply(new BigDecimal(b));
    }

    public static BigDecimal multiplyTwoScale(BigDecimal a, Double b) {
        if (null == b) {
            return BigDecimal.ZERO;
        }

        BigDecimal multiply = multiply(a, b);
        return multiply.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    public static BigDecimal multiplyTwoScale(Double a, Double b) {
        if (null == a || null == b) {
            return BigDecimal.ZERO;
        }

        return multiplyTwoScale(new BigDecimal(a), b);
    }

    /**
     * 把两个BigDecimal类型的参数a b相除，返回 a/b 相乘后的结果。
     * 两个参数都为null，则返回BigDecimal.ZERO。
     *
     * @param a 参数
     * @param b 参数
     * @return 返回相乘后的结果
     */
    public static BigDecimal divide(BigDecimal a, BigDecimal b) {
        if (a == null || b == null || BigDecimal.ZERO.equals(b)) {
            return BigDecimal.ZERO;
        }

        return a.divide(b, 2, BigDecimal.ROUND_HALF_UP);
    }

    public static BigDecimal divide(BigDecimal a, Integer b) {
        if (a == null || b == null || b == 0) {
            return BigDecimal.ZERO;
        }

        return a.divide(new BigDecimal(b), 2, BigDecimal.ROUND_HALF_UP);
    }

    public static BigDecimal divide(BigDecimal a, Double b) {
        if (a == null || b == null) {
            return BigDecimal.ZERO;
        }

        return a.divide(new BigDecimal(b), 2, BigDecimal.ROUND_HALF_UP);
    }

    public static int compareTo(BigDecimal a, BigDecimal b) {
        if (null == a) {
            return -1;
        }

        if (null == b) {
            return 1;
        }

        return a.compareTo(b);
    }

    /**
     * 数据三分一隔位符并保留两位小数
     */
    public static String formatToSeparate(double data) {
        DecimalFormat df = new DecimalFormat("#,###.00");
        return df.format(data);
    }
}
