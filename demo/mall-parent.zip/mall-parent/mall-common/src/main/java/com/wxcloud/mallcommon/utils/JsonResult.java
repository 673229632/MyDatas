package com.wxcloud.mallcommon.utils;

/**
 * 前后台交互实体类
 *
 */
public class JsonResult {

    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";

    private boolean success = true;
    private Object data;
    private String message;
    private String statusCode;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public JsonResult() { }

    public JsonResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public JsonResult(boolean success, String message,String statusCode) {
        this.success = success;
        this.message = message;
        this.statusCode = statusCode;
    }

    public JsonResult(boolean success, Object data) {
        this.success = success;
        this.data = data;
    }

    public JsonResult(boolean success, String message, Object data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }
    public JsonResult(boolean success, String message,String statusCode, Object data) {
        this.success = success;
        this.message = message;
        this.statusCode = statusCode;
        this.data = data;
    }

    /**
     * 成功返回，有提示语句,没有状态码
     * @param message
     * @param data
     * @return
     */
    public static JsonResult buildSuccessResult( String message, Object data){
        return new JsonResult(true,message,data);
    }

    /**
     * 成功返回，没有提示语和状态码
     * @param data
     * @return
     */
    public static JsonResult buildSuccessResult(Object data){
        return new JsonResult(true,data);
    }

    /**
     * 成功返回，有提示语和状态码
     * @param message
     * @param statusCode
     * @param data
     * @return
     */
    public static JsonResult buildSuccessResult(String message,String statusCode,Object data){
        return new JsonResult(true,message,statusCode,data);
    }

    /**
     * 失败返回，带实体类，没有状态码
     * @param message
     * @param data
     * @return
     */
    public static JsonResult buildFailureResult( String message, Object data){
        return new JsonResult(false,message,data);
    }

    /**
     * 失败返回，不带实体类,没有状态码
     * @param message
     * @return
     */
    public static JsonResult buildFailureResult( String message){
        return new JsonResult(false,message);
    }

    /**
     * 失败返回，不带实体类，没有状态码
     * @param message
     * @param statusCode
     * @return
     */
    public static JsonResult buildFailureResult(String message,String statusCode){
        return new JsonResult(false,message,statusCode);
    }
}
