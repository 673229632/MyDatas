package com.wxcloud.mallcommon.token;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * token配置参数
 *
 * @author feipeng
 */
@Configuration
@ConfigurationProperties(prefix = "wxcloud.token.jwt")
public class TokenProperties {

    /**
     * token有效时间
     */
    private Long expireTime;
    /**
     * token刷新时间
     */
    private Long refreshTime;
    /**
     * 密钥
     */
    private String secretKey;
    /**
     * token头前缀
     */
    private String headerPrefix;

    public Long getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getHeaderPrefix() {
        return headerPrefix;
    }

    public void setHeaderPrefix(String headerPrefix) {
        this.headerPrefix = headerPrefix;
    }

    public Long getRefreshTime() {
        return refreshTime;
    }

    public void setRefreshTime(Long refreshTime) {
        this.refreshTime = refreshTime;
    }
}
