package com.wxcloud.mallcommon.context;

import java.util.HashMap;
import java.util.Map;

/**
 * 基础线程变量类
 * 存放访问请求用户基本信息
 *
 * @author feipeng
 */
public class CommonContext {

    private static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();

    public static final String USER_ID = "userId";
    public static final String USER_NAME = "userName";
    public static final String ROLE_CODE = "roleCode";
    public static final String EMPLOYEE_CODE = "employee_code";
    public static final String TOKEN = "token";


    public static void set(String key, Object value) {
        Map<String, Object> map = threadLocal.get();
        if (null == map) {
            map = new HashMap<>(3);
            threadLocal.set(map);
        }
        map.put(key, value);
    }

    public static Object get(String key) {
        Map<String, Object> map = threadLocal.get();
        if (null == map) {
            map = new HashMap<>(3);
            threadLocal.set(map);
        }
        return map.get(key);
    }

    public static void setUserId(String value) {
        set(USER_ID, value);
    }

    public static String getUserId() {
        Map<String, Object> map = threadLocal.get();
        return (String) get(USER_ID);
    }

    public static void setUserName(String value) {
        set(USER_NAME, value);
    }

    public static String getUserName() {
        Map<String, Object> map = threadLocal.get();
        return (String) get(USER_NAME);
    }

    public static void setRoleCode(String value) {
        set(ROLE_CODE, value);
    }

    public static String getRoleCode() {
        Map<String, Object> map = threadLocal.get();
        return (String) get(ROLE_CODE);
    }

    public static void setEmployeeCode(String value) {
        set(EMPLOYEE_CODE, value);
    }

    public static String getEmployeeCode() {
        Map<String, Object> map = threadLocal.get();
        return (String) get(EMPLOYEE_CODE);
    }

    public static void setToken(String value) {
        set(TOKEN, value);
    }

    public static String getToken() {
        Map<String, Object> map = threadLocal.get();
        return (String) get(TOKEN);
    }

    public static void remove() {
        threadLocal.remove();
    }
}
