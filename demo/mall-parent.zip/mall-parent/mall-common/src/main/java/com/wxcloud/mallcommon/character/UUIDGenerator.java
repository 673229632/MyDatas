package com.wxcloud.mallcommon.character;

import java.util.UUID;

/**
 * UUID生成器
 *
 */
public class UUIDGenerator {

    /**
     * 获取32位UUID，去除UUID中的横杆之后的32位字符串
     *
     * @return 返回32位UUID
     */
    public static String getUUID32() {
        return getUUID().replaceAll("-", "");
    }

    /**
     * 获取UUID，有UUID中的横杠
     * 生成规则：32位字符串由本机的IP+时间无符号右移8位（当前中时间）+当前短时间+当前长时间+计数器 组成
     *
     * @return 返回UUID
     */
    public static String getUUID() {
        return UUID.randomUUID().toString();
    }

}
