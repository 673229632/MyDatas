package com.wxcloud.mallcommon.verify;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 校验工具类
 *
 * @author: sky
 * @date: 2017/10/19 17:17
 */
public class VerifyUtil {

    /**
     * 运营商号段如下：
     * 中国联通号码：130、131、132、145（无线上网卡）、155、156、185（iPhone5上市后开放）、186、176（4G号段）、
     * 175（2015年9月10日正式启用，暂只对北京、上海和广东投放办理）
     * 中国移动号码：134、135、136、137、138、139、147（无线上网卡）、150、151、152、157、158、159、182、183、187、188、178
     * 中国电信号码：133、153、180、181、189、177、173、149 虚拟运营商：170、1718、1719
     * 手机号前3位的数字包括：
     * 1 :1
     * 2 :3,4,5,7,8
     * 3 :0,1,2,3,4,5,6,7,8,9
     * 总结： 目前java手机号码正则表达式有：
     * a :"^1[3|4|5|7|8][0-9]\\d{4,8}$"    一般验证情况下这个就可以了
     * b :"^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17[013678])|(18[0,5-9]))\\d{8}$"
     * c :2018最新手机正则 "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$"
     */
//    private static Pattern PHONE_NUMBER = Pattern.compile("^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17[013678])|(18[0-9]))\\d{8}$");
    private static Pattern PHONE_NUMBER = Pattern.compile("^1[3|4|5|8|7|9][0-9]\\d{8}$");

    /**
     * 纯数字
     * <p>
     * 以数字开头
     * 1个或多个数字组成
     * 以数字结尾
     */
    private static Pattern NUMBER = Pattern.compile("^[0-9]+$");

    /**
     * 英文字母（包含大小写）
     * <p>
     * 以字母开头
     * 1个或多个字母组成
     * 以字母结尾
     */
    private static Pattern LETTER = Pattern.compile("^[a-zA-Z]+$");

    /**
     * 包含字母或数字
     * <p>
     * 以字母或数字开头
     * 1个或多个字母或数字组成
     * 以字母或数字结尾
     */
    private static Pattern NUMBER_OR_LETTER = Pattern.compile("^[a-zA-Z0-9]+$");

    /**
     * 包含字母或数字或下划线
     * <p>
     * 以字母或数字或下划线开头
     * 1个或多个字母或数字或下划线组成
     * 以字母或数字或下划线结尾
     */
    private static Pattern NUMBER_OR_LETTER_OR_UNDERLINE = Pattern.compile("^\\w+$");

    /**
     * 检查是否为手机号
     *
     * @param content
     * @return
     */
    public static boolean isPhoneNumber(String content) {
        if (StringUtils.isEmpty(content)) {
            return false;
        }
        return PHONE_NUMBER.matcher(content).find();
    }


    /**
     * 是否为纯数字
     *
     * @return true 数字
     */
    public static boolean isNumber(final String content) {
        return NUMBER.matcher(content).find();
    }

    /**
     * 是否纯英文字母
     *
     * @return true 数字
     */
    public static boolean isLetter(final String content) {
        return LETTER.matcher(content).find();
    }

    /**
     * 包含字母或数字
     *
     * @param content
     * @return
     */
    public static boolean isNumberOrLetter(final String content) {
        return NUMBER_OR_LETTER.matcher(content).find();
    }

    /**
     * 包含字母或数字或下划线
     *
     * @param content
     * @return
     */
    public static boolean isNumberOrLetterOrUnderline(final String content) {
        return NUMBER_OR_LETTER_OR_UNDERLINE.matcher(content).find();
    }


    /**
     * 检查是否为邮箱
     *
     * @param content
     * @return
     */
    public static boolean isEmail(String content) {
        boolean result = false;
        if (StringUtils.isNotBlank(content)) {
            String regexEmail = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
            Pattern pattern = Pattern.compile(regexEmail);
            Matcher matcher = pattern.matcher(content);
            if (matcher.matches()) {
                result = true;
            }
        }
        return result;
    }

}
