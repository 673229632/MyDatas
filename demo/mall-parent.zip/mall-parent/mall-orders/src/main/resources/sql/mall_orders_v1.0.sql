
CREATE TABLE t_orders_order (
  id varchar(32) PRIMARY KEY,
  order_no varchar(20) NOT NULL COMMENT '订单号',
  user_id varchar(32) NOT NULL COMMENT '外键，用户id，注意并不是openid',
  total_price decimal(6,2) NOT NULL,
  status tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:未支付， 2：已支付，3：已发货 , 4: 已支付，但库存不足',
  snap_img varchar(255) DEFAULT NULL COMMENT '订单快照图片',
  snap_name varchar(80) DEFAULT NULL COMMENT '订单快照名称',
  total_count varchar(32) NOT NULL DEFAULT '0',
  snap_items text COMMENT '订单其他信息快照（json)',
  snap_address varchar(500) DEFAULT NULL COMMENT '地址快照',
  prepay_id varchar(100) DEFAULT NULL COMMENT '订单微信支付的预订单id（用于发送模板消息）',
  create_by varchar(32),
  create_at timestamp(6),
  update_by varchar(32),
  updated_at timestamp(6),
  corp_code varchar(50)
) COMMENT='点单表';