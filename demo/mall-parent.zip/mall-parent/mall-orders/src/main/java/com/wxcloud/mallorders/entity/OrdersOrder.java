package com.wxcloud.mallorders.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.wxcloud.mall.mallmybatisplus.base.BaseModel;

@TableName("t_orders_order")
public class OrdersOrder extends BaseModel {

    private static final long serialVersionUID = -1287453534617697148L;

}
