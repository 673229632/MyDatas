package com.wxcloud.mallorders;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableEurekaClient
@MapperScan("com.wxcloud.mallorders.mapper")
@EnableFeignClients
public class MallOrdersApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallOrdersApplication.class, args);
    }
}
