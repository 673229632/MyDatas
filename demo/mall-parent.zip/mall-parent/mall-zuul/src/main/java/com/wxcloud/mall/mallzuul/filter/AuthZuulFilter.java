package com.wxcloud.mall.mallzuul.filter;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import com.wxcloud.mall.mallzuul.config.AuthZuulConfig;
import com.wxcloud.mallcommon.context.CommonContext;
import com.wxcloud.mallcommon.exception.UnAuthorizedException;
import com.wxcloud.mallcommon.token.TokenFactory;
import org.springframework.cloud.netflix.zuul.filters.support.FilterConstants;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 权限连接器
 */
@Component
public class AuthZuulFilter extends ZuulFilter {

    private static final PathMatcher PATH_MATCHER = new AntPathMatcher();

    @Resource
    private AuthZuulConfig authZuulConfig;

    /**
     * filterType：该函数需要返回一个字符串来代表过滤器的类型，而这个类型就是在HTTP请求过程中定义的各个阶段。
     * 在Zuul中默认定义了四种不同生命周期的过滤器类型，具体如下：
     * <p>
     * pre：可以在请求被路由之前调用。
     * {@link org.springframework.cloud.netflix.zuul.filters.support.FilterConstants#PRE_TYPE}
     * <p>
     * route：在路由请求时候被调用。
     * {@link org.springframework.cloud.netflix.zuul.filters.support.FilterConstants#ROUTE_TYPE}
     * <p>
     * post：在 route 和 error 过滤器之后被调用。
     * {@link org.springframework.cloud.netflix.zuul.filters.support.FilterConstants#POST_TYPE}
     * <p>
     * error：处理请求时发生错误时被调用。
     * {@link org.springframework.cloud.netflix.zuul.filters.support.FilterConstants#ERROR_TYPE}
     */
    @Override
    public String filterType() {
        return FilterConstants.PRE_TYPE;
    }

    /**
     * 通过int值来定义过滤器的执行顺序，数值越小优先级越高
     */
    @Override
    public int filterOrder() {
        return FilterConstants.PRE_DECORATION_FILTER_ORDER - 1;
    }

    /**
     * 返回一个boolean类型来判断该过滤器是否要执行。可以通过此方法来指定过滤器的有效范围。不参加过滤url返回false
     */
    @Override
    public boolean shouldFilter() {
//        RequestContext context = RequestContext.getCurrentContext();
//        HttpServletRequest request = context.getRequest();
//        String servletPath = request.getServletPath();
//        //忽略过滤url集合
//        List<String> ignoreChecks = authZuulConfig.getIgnoreChecks();
//        ignoreChecks.add("/**");
//
//        for (String ignoreCheck : ignoreChecks) {
//            boolean match = PATH_MATCHER.match(ignoreCheck, servletPath);
//            if (!match) {
//                return true;
//            }
//        }
//
        return false;
//        return true;
    }

    /**
     * 业务逻辑处理
     * <p>
     * 1。获取token进行 登录校验
     * 2。权限校验
     */
    @Override
    public Object run() throws ZuulException {
        // 获取token
        RequestContext context = RequestContext.getCurrentContext();
        HttpServletRequest request = context.getRequest();
        String token = request.getHeader("Authorization");
        //解析token
        try {
            Map<String, Object> map = TokenFactory.validateToken(token);
            String userId = String.valueOf(map.get(CommonContext.USER_ID));
            String userName = String.valueOf(map.get(CommonContext.USER_NAME));
            String employeeCode = String.valueOf(map.get(CommonContext.EMPLOYEE_CODE));
            //将人员信息存入线程变量中
//            CommonContext.setUserId(userId);
//            CommonContext.setUserName(userName);
//            CommonContext.setEmployeeCode(employeeCode);

            context.addZuulRequestHeader(CommonContext.USER_ID, userId);
            context.addZuulRequestHeader(CommonContext.USER_NAME, userName);
            context.addZuulRequestHeader(CommonContext.EMPLOYEE_CODE, employeeCode);
            context.addZuulRequestHeader(CommonContext.TOKEN, token);
        } catch (UnAuthorizedException e) {
            context.setResponseBody("token异常");
            return null;
        } catch (Exception e) {
            context.setResponseBody("token异常");
            return null;
        }

        //判断引用或数据权限等
        //不需要验证权限url校验
        //需要验证权限url
        return null;
    }
}
