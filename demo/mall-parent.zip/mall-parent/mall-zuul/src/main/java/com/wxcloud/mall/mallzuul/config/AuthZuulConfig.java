package com.wxcloud.mall.mallzuul.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 权限配置类
 */
@Component
@ConfigurationProperties(prefix = "auth.zuul")
public class AuthZuulConfig {

    private List<String> ignoreChecks = new ArrayList<>();

    public List<String> getIgnoreChecks() {
        return ignoreChecks;
    }

    public void setIgnoreChecks(List<String> ignoreChecks) {
        this.ignoreChecks = ignoreChecks;
    }
}
