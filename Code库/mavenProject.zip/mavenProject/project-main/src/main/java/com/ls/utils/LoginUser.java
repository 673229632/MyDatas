/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: LoginUser.java
 * @类路径: com.ls.utils
 */

package com.ls.utils;

import java.io.Serializable;

/**
 * 登录实体类  用户名，密码，验证码
 * @see		
 * @author  lyguan
 * @date	2017年7月10日 上午11:21:58
 * @version	 
 * @desc    TODO
 */
public class LoginUser implements Serializable {
	
	/**
	 * 序列化
	 */
	private static final long serialVersionUID = -1661228964098077400L;
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	private String password;
	/**
	 * 验证码
	 */
	private String captcha;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCaptcha() {
		return captcha;
	}
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	
	
	

}

