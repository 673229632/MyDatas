/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: SessionUtils.java
 * @类路径: com.ls.utils
 */

package com.ls.utils;

/**
 *
 * @see		
 * @author  lyguan
 * @date	2017年7月9日 下午6:18:59
 * @version	 
 * @desc    TODO
 */
public class SessionUtils {
	/**
	 * session中保存user的key.
	 * @fieldName SESSION_USER
	 * @fieldType String
	 */
	public static final String SESSION_USER = "SESSION__USER__KEY";
	/**
	 * session中保存验证码的key.
	 * @fieldName SESSION_CAPTCHA
	 * @fieldType String
	 */
	public static final String SESSION_CAPTCHA = "captcha";
	
	
}
