/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: IConfigService.java
 * @类路径: com.ls.config.service.impl
 */

package com.ls.config.service;

import com.ls.config.domain.SysConfig;

/**
 *
 * @see		
 * @author  lyguan
 * @date	2017年7月9日 下午6:29:08
 * @version	 
 * @desc    TODO
 */
public interface IConfigService {

	/**
	 * 系统配置信息
	 * @see
	 * @Title: getSysConfig  
	 * @author gly_ls
	 * @return
	 * @throws Exception     
	 * @return SysConfig    返回类型
	 */
	SysConfig getSysConfig() throws Exception;
}

