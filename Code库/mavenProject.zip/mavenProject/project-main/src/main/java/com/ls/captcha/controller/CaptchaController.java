/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: CaptchaController.java
 * @类路径: com.ls.captcha.controller
 */

package com.ls.captcha.controller;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ImageIcon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ls.captcha.CaptchaUtil;
import com.ls.captcha.CaptchaUtil.Captcha;

/**
 * 显示验证码
 * @see		
 * @author  lyguan
 * @date	2017年7月10日 上午10:20:19
 * @version	 
 * @desc    TODO
 */
@Controller
public class CaptchaController {

	/**
	 * logger 
	 */
	private static Logger logger = LoggerFactory.getLogger(CaptchaController.class);
	
	/**
	 * 验证码工具
	 */
	@Autowired
	private CaptchaUtil captchaUtil;


	public void setCaptchaUtil(CaptchaUtil captchaUtil) {
		this.captchaUtil = captchaUtil;
	} 
	

	/**
	 * 处理验证码请求
	 * @Title  generateCaptcha 
	 * @Description  TODO
	 * @author  Administrator
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return  String
	 */
	@RequestMapping("/captcha")
	public String generateCaptcha(HttpServletRequest request,  HttpServletResponse response) throws Exception {
		//获取验证码
		Captcha captcha = captchaUtil.getCode();
		if(logger.isInfoEnabled()){
			logger.info("生成的验证码=" + captcha.getCode());
		}
		//保存到session
		request.getSession().setAttribute("captcha", captcha.getCode());
		//将图片输出到页面，并禁止图片缓存
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0L);
		response.setContentType("image/jpeg");
		ServletOutputStream sos = null;
		try {
			//将图片输出到servlet输出流中
			sos = response.getOutputStream();
			byte[] image = transferAlpha(captcha.getImage());
			sos.write(image);
			sos.close();
		} catch (Exception localException) {
			if (sos != null){
				try {
					sos.close();
				} catch (IOException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}	
		} finally {
			if (sos != null) {
				try {
					sos.close();
				} catch (IOException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	
	/**
	 * 
	 * 设置图片为png格式，并且背景透明
	 * @Title  transferAlpha 
	 * @Description  TODO
	 * @author  Administrator
	 * @param image
	 * @return
	 * @return  byte[]
	 */
	public byte[] transferAlpha(Image image) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			ImageIcon imageIcon = new ImageIcon(image);
			BufferedImage bufferedImage = new BufferedImage(
					imageIcon.getIconWidth(),
					imageIcon.getIconHeight(), BufferedImage.TYPE_4BYTE_ABGR);
			Graphics2D g2D = (Graphics2D) bufferedImage.getGraphics();
			g2D.drawImage(imageIcon.getImage(), 0, 0, imageIcon.getImageObserver());
			int alpha = 0;
			for (int j1 = bufferedImage.getMinY(); j1 < bufferedImage.getHeight(); j1++) {
				for (int j2 = bufferedImage.getMinX(); j2 < bufferedImage.getWidth(); j2++) {
					int rgb = bufferedImage.getRGB(j2, j1);
					int r = (rgb & 0xff0000) >> 16;
					int g = (rgb & 0xff00) >> 8;
					int b = (rgb & 0xff);
					if (((255 - r) < 30) && ((255 - g) < 30) && ((255 - b) < 30)) {
						rgb = ((alpha + 1) << 24) | (rgb & 0x00ffffff);
					}
					bufferedImage.setRGB(j2, j1, rgb);
				}
			}
			g2D.drawImage(bufferedImage, 0, 0, imageIcon.getImageObserver());
			// ImageIO.write(bufferedImage, "png", new File("d:/test.png.png"));
			// !!! 写入内存
			ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(e.toString());
		}
		return byteArrayOutputStream.toByteArray();
	}
}

