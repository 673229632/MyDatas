/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: SysUserServiceImpl.java
 * @类路径: com.ls.index.service.impl
 */

package com.ls.index.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ls.index.dao.SysUserMapper;
import com.ls.index.domain.SysUser;
import com.ls.index.service.ISysUserService;

/**
 * 用户service
 * @see		
 * @author  lyguan
 * @date	2017年7月9日 下午6:00:51
 * @desc    TODO
 */
@Service
public class SysUserServiceImpl implements ISysUserService {

	@Autowired
	private SysUserMapper sysUserMapper;
	
	
	public SysUser getUserByUserName(String username) {
		List<SysUser> userList = sysUserMapper.selectByUserName(username);
		if(userList != null && userList.size() > 0){
			return userList.get(0);
		}
		return null;
	}

}

