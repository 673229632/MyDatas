/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: ISysUserService.java
 * @类路径: com.ls.index.service
 */

package com.ls.index.service;

import com.ls.index.domain.SysUser;

/**
 *
 * @see		
 * @author  lyguan
 * @date	2017年7月9日 下午6:00:13
 * @version	 
 * @desc    TODO
 */
public interface ISysUserService {

	/**
	 * 
	 * @param username
	 * @return
	 */
	SysUser getUserByUserName(String username);
}

