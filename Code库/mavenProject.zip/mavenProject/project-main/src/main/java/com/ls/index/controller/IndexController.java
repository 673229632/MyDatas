/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: IndexController.java
 * @类路径: com.ls.index.controller
 */

package com.ls.index.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.ls.config.domain.SysConfig;
import com.ls.config.service.IConfigService;
import com.ls.index.domain.SysUser;
import com.ls.index.service.ISysUserService;
import com.ls.menu.domain.Menu;
import com.ls.menu.service.IMenuService;
import com.ls.utils.Constant;
import com.ls.utils.GetTime;
import com.ls.utils.LoginUser;
import com.ls.utils.SessionUtils;
import com.ls.utils.md5.Md5Utils;

/**
 * 登录controller
 * 
 * @see
 * @author lyguan
 * @date 2017年7月9日 下午6:03:39
 * @version
 * @desc TODO
 */
@Controller
@RequestMapping("/")
public class IndexController {

	/**
	 * 日志
	 */
	private static Logger logger = LoggerFactory.getLogger(IndexController.class);
	/**
	 * 注入IConfigService
	 */
	@Autowired
	private IConfigService configService;

	/**
	 * 注入 ISysUserService
	 */
	@Autowired
	private ISysUserService sysUserService;

	@Autowired
	private IMenuService menuService;
	
	/**
	 * 默认路径跳转登录页面
	 * 
	 * @return
	 */
	@RequestMapping(value = { "", "/" }, method = RequestMethod.GET)
	public void homePage(HttpServletResponse response, HttpServletRequest request) {
		try {
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Expires", 0);
			response.addHeader("Cache-Control", "no-cache"); // 浏览器和缓存服务器都不应该缓存页面信息
			response.addHeader("Cache-Control", "no-store"); // 请求和响应的信息都不应该被存储在对方的磁盘系统中；
			response.addHeader("Cache-Control", "must-revalidate");
			response.sendRedirect(request.getContextPath() + "/index");
		} catch (Exception e) {
			logger.error("HomeController->homePage");
			e.printStackTrace();
		}
	}

	/**
	 * index主界面入口
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/index")
	public String index(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		// 获取session
		HttpSession session = request.getSession();
		// 获取session中的user
		SysUser sysUser = (SysUser) session.getAttribute(SessionUtils.SESSION_USER);
		// session为空，则重定位到login页面
		if (sysUser == null) {
			return "redirect:/login";
		}
		// 获取系统当前时间
		Date nowDate = new Date();
		String week = GetTime.getWeek(nowDate);
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		List<Menu> firstMenu = menuService.getFirstMenu();
		List<Menu> secondMenu = menuService.getSecondMenu();
		SysConfig sysConfig = configService.getSysConfig();
		//登录者信息
		model.addAttribute("sysConfig", sysConfig);
		model.addAttribute("customuser", sysUser);
		model.addAttribute("week", week);
		model.addAttribute("year", year);
		model.addAttribute("day", day);
		model.addAttribute("month", month);
		model.addAttribute("firstMenu", firstMenu);
		model.addAttribute("secondMenu", secondMenu);
		return "/index/index";
	}

	/**
	 * 用户登录界面
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping("/login")
	public String login(Model model) {
		SysConfig sysConfig = null;
		try {
			sysConfig = configService.getSysConfig();
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("sysConfig", sysConfig);
		return "/login";
	}

	/**
	 * 登出
	 * @see
	 * @Title: logout  
	 * @author gly_ls
	 * @param response
	 * @param request     
	 * @return void    返回类型
	 */
	@RequestMapping(value = { "/logout", "/logout/" })
	public void logout(HttpServletResponse response, HttpServletRequest request) {
		try {
			// 移除用户，销毁Session
			HttpSession session = request.getSession();
			session.removeAttribute(SessionUtils.SESSION_USER);
			session.invalidate();
			response.sendRedirect(request.getContextPath() + "/login");
		} catch (Exception e) {
			logger.error("HomeController->logout");
			e.printStackTrace();
		}
	}
	
	/**
	 * 验证登录信息
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/doLogin" ,produces="application/json;charset=UTF-8")
	@ResponseBody
	public String doLogin(@ModelAttribute LoginUser user, HttpServletRequest request) {
		// 获取session
		HttpSession session = request.getSession();
		// 创建json对象
		JSONObject returnObj = new JSONObject();
		// 判断验证码是否正确
		String captcha = (String) session.getAttribute(Constant.SESSION_CAPTCHA);
		if (!user.getCaptcha().equals(captcha)) {
			returnObj.put(Constant.STATUS, -1);
			returnObj.put("msg", "验证码输入错误");
			return returnObj.toJSONString();
		}
		// 判断账号是否存在
		SysUser sysUser = null;
		try {
			sysUser = sysUserService.getUserByUserName(user.getUsername());
		} catch (Exception e) {
			logger.error("IndexController->doLogin->doLogin");
			e.printStackTrace();
		}
		if (sysUser == null) {
			returnObj.put(Constant.STATUS, -1);
			returnObj.put("msg", "账号不存在");
			return returnObj.toJSONString();
		}
		// 判断密码是否正确
		if (sysUser != null) {
			String userPwd = sysUser.getPassword();
			//md5加密是不可逆的，判断是将输入密码进行加密，再与数据库的值进行对比
			if (!Md5Utils.string2MD5(user.getPassword()).equals(userPwd)) {
				returnObj.put(Constant.STATUS, -1);
				returnObj.put("msg", "密码错误");
				return returnObj.toJSONString();
			}
		}
		request.getSession().setAttribute(SessionUtils.SESSION_USER, sysUser);
		returnObj.put(Constant.STATUS, 1);
		return returnObj.toJSONString();
	}
}
