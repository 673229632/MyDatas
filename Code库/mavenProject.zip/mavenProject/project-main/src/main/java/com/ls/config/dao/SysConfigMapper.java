package com.ls.config.dao;

import java.util.List;

import com.ls.config.domain.SysConfig;
import com.ls.utils.database.MybatisMapper;

public interface SysConfigMapper extends MybatisMapper<SysConfig> {
	
	/**
	 * 查询所有的配置，只有一条数据，防止id值改变，报错
	 * @see
	 * @Title: selectAllConfig  
	 * @author gly_ls
	 * @return     
	 * @return List<SysConfig>    返回类型
	 */
	List<SysConfig> selectAllConfig();
}