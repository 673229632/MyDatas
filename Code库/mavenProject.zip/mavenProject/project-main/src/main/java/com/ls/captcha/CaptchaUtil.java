package com.ls.captcha;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;

import org.springframework.util.Assert;

/**
 * CaptchaUtil
 * @ClassName  CaptchaUtil 
 * @Description  TODO
 * @author  Administrator
 * @date  2017年3月6日 上午10:56:39
 */
public class CaptchaUtil {
	/**
	 * 验证码设置
	 * 需要注入验证码设置信息，如果没有注入，则需要自己创建
	 */
	private CaptchaSetting captchaSetting;
	
	/**
	 * set the captchaSetting
	 * @param captchaSetting the captchaSetting to set
	 */
	public void setCaptchaSetting(CaptchaSetting captchaSetting) {
		this.captchaSetting = captchaSetting;
	}
	
	/**
	 * 生成验证码
	 * @Title  getCode 
	 * @author  zhangshun
	 * @return  Captcha 包含验证码图片以及实际验证码字符
	 */
	public Captcha getCode() {
		// 1.先准备准备
		Assert.notNull(captchaSetting);
		// 验证码宽度
		Integer imageWidth = captchaSetting.getImageWidth();
		// 验证码宽度
		Integer imageHeight = captchaSetting.getImageHeight();
		// 验证码字体信息
		Font font = captchaSetting.getFont();
		// 验证码个数
		Integer captchaLength = captchaSetting.getCaptchaLength();
		// 验证码来源
		String captchaSource = captchaSetting.getCaptchaSource();
		// 验证码字符间距
		Integer gap = captchaSetting.getGap();
		// X增量
		Integer xIncrement = captchaSetting.getXIncrement();
		// Y增量
		Integer yIncrement = captchaSetting.getYIncrement();
		// 是否存在干扰线
		Boolean hasDisturb = captchaSetting.getHasDisturb();
		//干扰线条数
		Integer disturbSize = captchaSetting.getDisturbSize();
		
		// 创建一个随机数生成器类
		Random random = new Random();
		
		// 2.先画边框，验证码最后画，干扰线可画可不画
		BufferedImage buffImg = new BufferedImage(
				imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = buffImg.createGraphics();
		g.fillRect(0, 0, imageWidth, imageHeight);
		// 设置字体信息
		g.setFont(font);
		// 画边框
		g.drawRect(0, 0, imageWidth - 1, imageHeight - 1);
		StringBuffer randomCode = new StringBuffer();
		
		// 画验证码
		for (int i = 0; i < captchaLength; i++) {
			int start = random.nextInt(captchaSource.length());
			String strRand = captchaSource.substring(start, start + 1);
			g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110),
					20 + random.nextInt(110)));
			// x值使用间隙加X增量，y值使用验证码图片的高度+Y增量
			g.drawString(strRand, gap * i + xIncrement, 
					captchaSetting.getImageHeight() + yIncrement);
			randomCode.append(strRand);
		}
		
		// 画干扰线
		if(hasDisturb){
			// 生成干扰线
			g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110),
					20 + random.nextInt(110)));
			for(int index = 0; index < disturbSize; index++){
				int x = random.nextInt(imageWidth);
				int y = random.nextInt(imageHeight);
				int x1 = random.nextInt(imageWidth);
				int y1 = random.nextInt(imageHeight);
				g.drawLine(x, y, x+x1, y+y1);
			}
		}
		
		g.dispose();
		// 返回验证码
		Captcha captcha = new Captcha(buffImg, randomCode.toString());
		return captcha;
	}

	/**
	 * 验证码
	 * @ClassName  Captcha 
	 * @Description 包含验证码图片以及验证码字符
	 * @author  zhangshun
	 * @date  2016年8月24日 上午11:13:48
	 */
	public class Captcha{
		/**
		 * 验证码图片
		 */
		private BufferedImage image;
		/**
		 * 验证码字符
		 */
		private String code;
		/**
		 * 默认构造方法
		 * @Title Captcha
		 */
		public Captcha(){	
		}
		/** 
		 * 构造方法
		 * @Title Captcha
		 * @param image
		 * @param code 
		 */
		public Captcha(BufferedImage image, String code) {
			super();
			this.image = image;
			this.code = code;
		}
		/**
		 * return the image
		 * @return the image
		 */
		public BufferedImage getImage() {
			return image;
		}
		/**
		 * set the image
		 * @param image the image to set
		 */
		public void setImage(BufferedImage image) {
			this.image = image;
		}
		/**
		 * return the code
		 * @return the code
		 */
		public String getCode() {
			return code;
		}
		/**
		 * set the code
		 * @param code the code to set
		 */
		public void setCode(String code) {
			this.code = code;
		}
	}
}
