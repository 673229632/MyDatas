package com.ls.config.domain;

import java.io.Serializable;

public class SysConfig implements Serializable{
    /**  
	 * @author gly_ls
	 * @time 2017年7月29日
	*/  
	private static final long serialVersionUID = 6300699818491393525L;

	/**
	 * id
	 */
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 页脚
     */
    private String copyright;

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getCopyright() {
        return copyright;
    }
    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }
}