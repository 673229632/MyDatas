package com.ls.captcha;

import java.awt.Font;

import org.slf4j.Logger;

/**
 * CaptchaSetting
 * @ClassName  CaptchaSetting 
 * @Description  TODO
 * @author  Administrator
 * @date  2017年3月6日 上午10:56:30
 */
public class CaptchaSetting {
	/**
	 * 日志对象
	 */
	private Logger logger = org.slf4j.LoggerFactory.getLogger(getClass());
	/**
	 * 默认生成的验证码宽度
	 */
	public static final Integer DEFAULT_IMAGE_WIDTH = 85;
	/**
	 * 默认生成的验证码高度
	 */
	public static final Integer DEFAULT_IMAGE_HEIGHT = 33;
	/**
	 * 默认验证码中的字体信息
	 */
	public static final Font DEFAULT_FONT = new Font("微软雅黑", Font.PLAIN, 28);
	/**
	 * 默认生成的验证码个数
	 */
	public static final Integer DEFAULT_CAPTCAHA_LENGTH = 4;
	/**
	 * 默认验证码来源
	 */
	public static final String DEFAULT_CAPTCHA_SOURCE = 
			"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	/**
	 * 默认验证码字符间距
	 */
	public static final Integer DEFAULT_GAP = 20;
	/**
	 * 默认X增量值
	 */
	private static final Integer DEFAULT_XINCREMENT = 6;
	/**
	 * 默认Y增量值
	 */
	private static final Integer DEFAULT_YINCREMENT = -4;
	/**
	 * 默认没有干扰线
	 */
	private static final Boolean DEFAULT_HAS_DISTURB = Boolean.FALSE;
	/**
	 * 默认干扰线条数
	 */
	private static final Integer DEFAULT_DISTURB_SIZE = 15;
	/**
	 * 生成的验证码宽度
	 */
	private Integer imageWidth;
	/**
	 * 生成的验证码高度
	 */
	private Integer imageHeight;
	/**
	 * 验证码中的字体信息
	 */
	private Font font;
	/**
	 * 生成的验证码个数
	 */
	private Integer captchaLength;
	/**
	 * 验证码来源
	 */
	private String captchaSource;
	/**
	 * 生成的验证码字符间距
	 */
	private Integer gap;
	/**
	 * 生成的字符位置的横坐标增量，可正可负
	 * 主要用于调整字符在图片中的位置
	 * 如：验证码的第一个字符距离图片左边太近，导致第一个验证码部门被盖住，
	 * 可以使用此增量调整第一个字符与图片左边的距离
	 */
	private Integer xIncrement;
	/**
	 * 生成的字符位置的纵坐标增量，可正可负
	 * 主要用于调整字符在图片中的位置
	 * 如：验证码的某个字符过于偏下，可以使用此增量调高该字符
	 */
	private Integer yIncrement;
	/**
	 * 是否有干扰线
	 */
	private Boolean hasDisturb;
	/**
	 * 干扰线条数
	 */
	private Integer disturbSize;
	
	/**
	 * return the imageWidth
	 * @return the imageWidth
	 */
	public Integer getImageWidth() {
		if (imageWidth == null || imageWidth < 10) {
			logger.warn("未设置生成的验证码宽度或设置的验证码宽度{}过小，将使用默认宽度{}", imageWidth, DEFAULT_IMAGE_WIDTH);
			return DEFAULT_IMAGE_WIDTH;
		}
		return imageWidth;
	}
	/**
	 * set the imageWidth
	 * @param imageWidth the imageWidth to set
	 */
	public void setImageWidth(Integer imageWidth) {
		this.imageWidth = imageWidth;
	}
	/**
	 * return the imageHeight
	 * @return the imageHeight
	 */
	public Integer getImageHeight() {
		if (imageHeight == null || imageHeight < 10) {
			logger.warn("未设置生成的验证码高度或设置的验证码高度{}过小，将使用默认高度{}", imageHeight, DEFAULT_IMAGE_HEIGHT);
			return DEFAULT_IMAGE_HEIGHT;
		}
		return imageHeight;
	}
	/**
	 * set the imageHeight
	 * @param imageHeight the imageHeight to set
	 */
	public void setImageHeight(Integer imageHeight) {
		this.imageHeight = imageHeight;
	}
	/**
	 * return the font
	 * @return the font
	 */
	public Font getFont() {
		if (font == null) {
			logger.warn("未设置生成的验证码的字体信息，将使用默认字体信息{}", DEFAULT_FONT.toString());
			return DEFAULT_FONT;
		}
		return font;
	}
	/**
	 * set the font
	 * @param font the font to set
	 */
	public void setFont(Font font) {
		this.font = font;
	}
	/**
	 * return the captchaLength
	 * @return the captchaLength
	 */
	public Integer getCaptchaLength() {
		if (captchaLength == null || captchaLength <= 0) {
			logger.warn("未设置生成的验证码个数或者设置的生成验证个数<=0，将使用默认生成验证码个数{}", DEFAULT_CAPTCAHA_LENGTH);
			return DEFAULT_CAPTCAHA_LENGTH;
		}
		return captchaLength;
	}
	/**
	 * set the captchaLength
	 * @param captchaLength the captchaLength to set
	 */
	public void setCaptchaLength(Integer captchaLength) {
		this.captchaLength = captchaLength;
	}
	/**
	 * return the captchaSource
	 * @return the captchaSource
	 */
	public String getCaptchaSource() {
		if (captchaSource == null || "".equals(captchaSource)) {
			logger.warn("未设置验证码来源或者设置的验证码来源为空，将使用默认值{}", DEFAULT_CAPTCHA_SOURCE);
			return DEFAULT_CAPTCHA_SOURCE;
		}
		return captchaSource;
	}
	/**
	 * set the captchaSource
	 * @param captchaSource the captchaSource to set
	 */
	public void setCaptchaSource(String captchaSource) {
		this.captchaSource = captchaSource;
	}
	/**
	 * return the xIncrement
	 * @return the xIncrement
	 */
	public Integer getXIncrement() {
		if(xIncrement == null){
			logger.warn("未设置X增量或者设置的X增量为空，将使用默认值{}", DEFAULT_XINCREMENT);
			return DEFAULT_XINCREMENT;
		}
		return xIncrement;
	}
	/**
	 * set the xIncrement
	 * @param xIncrement the xIncrement to set
	 */
	public void setXIncrement(Integer xIncrement) {
		this.xIncrement = xIncrement;
	}
	/**
	 * return the yIncrement
	 * @return the yIncrement
	 */
	public Integer getYIncrement() {
		if(yIncrement == null){
			logger.warn("未设置Y增量或者设置的Y增量为空，将使用默认值{}", DEFAULT_YINCREMENT);
			return DEFAULT_YINCREMENT;
		}
		return yIncrement;
	}
	/**
	 * set the yIncrement
	 * @param yIncrement the yIncrement to set
	 */
	public void setYIncrement(Integer yIncrement) {
		this.yIncrement = yIncrement;
	}
	
	/**
	 * return the gap
	 * @return the gap
	 */
	 
	public Integer getGap() {
		if(gap == null || gap <= 0){
			logger.warn("未设置字符间距或者设置的字符间距为空或者设置的字符间距为非正数，将使用默认值{}", DEFAULT_GAP);
			return DEFAULT_GAP;
		}
		return gap;
	}
	
	/**
	 * set the gap
	 * @param gap the gap to set
	 */
	 
	public void setGap(Integer gap) {
		this.gap = gap;
	}
	
	/**
	 * return the hasDisturb
	 * @return the hasDisturb
	 */
	 
	public Boolean getHasDisturb() {
		if(hasDisturb == null){
			logger.warn("未设置是否存在干扰线或者设置的是否存在干扰线为空，将使用默认值{}", DEFAULT_HAS_DISTURB);
			return DEFAULT_HAS_DISTURB;
		}
		return hasDisturb;
	}
	
	/**
	 * set the hasDisturb
	 * @param hasDisturb the hasDisturb to set
	 */
	 
	public void setHasDisturb(Boolean hasDisturb) {
		this.hasDisturb = hasDisturb;
	}
	
	/**
	 * return the disturbSize
	 * @return the disturbSize
	 */
	 
	public Integer getDisturbSize() {
		if(disturbSize == null || disturbSize <=0 ){
			logger.warn("未设置干扰线条数或者设置的干扰线条数为空或者设置的干扰线条数为非正数，将使用默认值{}", DEFAULT_DISTURB_SIZE);
			return DEFAULT_DISTURB_SIZE;
		}
		return disturbSize;
	}
	
	/**
	 * set the disturbSize
	 * @param disturbSize the disturbSize to set
	 */
	 
	public void setDisturbSize(Integer disturbSize) {
		this.disturbSize = disturbSize;
	}
}
