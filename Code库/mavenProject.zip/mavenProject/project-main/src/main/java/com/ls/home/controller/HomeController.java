/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: HomeController.java
 * @类路径: com.ls.home.controller
 */

package com.ls.home.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @see		
 * @author  gly_ls
 * @date	2017年9月20日 下午3:58:07
 * @version	 
 * @desc    TODO
 */
@Controller
@RequestMapping("/web/home")
public class HomeController {
	/**
	 * 首页
	 * @see
	 * @Title: init  
	 * @author gly_ls
	 * @param request
	 * @param response
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/init")
	public String init(HttpServletRequest request, HttpServletResponse response){
		return "/index/home";
	}
	/**
	 * 个人相册
	 * @see
	 * @Title: photo  
	 * @author gly_ls
	 * @param request
	 * @param response
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("photo")
	public String photo(HttpServletRequest request, HttpServletResponse response){
		return "/photo/photo";
	}
}

