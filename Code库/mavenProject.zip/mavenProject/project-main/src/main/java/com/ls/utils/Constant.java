/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: Constant.java
 * @类路径: com.ls.utils
 */

package com.ls.utils;

/**
 * 定义常量
 * @see		
 * @author  lyguan
 * @date	2017年7月9日 下午5:54:50
 * @version	 
 * @desc    TODO
 */
public class Constant {

	/**
	 * session保存用户信息的key
	 */
	public static final String SESSION_SYSUSER = "sys_user";
	
	
	/**
	 * session中保存验证码的key.
	 * @fieldName SESSION_CAPTCHA
	 * @fieldType String
	 */
	public static final String SESSION_CAPTCHA = "captcha";	
	/**
	 * 状态
	 */
	public static final String STATUS = "status";
	/**
	 * 数据验证错误
	 */
	public static final String ERRORS = "errors";
	
	/**
	 * 菜单编辑一级菜单编码
	 */
	public static final String MENUCODE1="1001";
	/**
	 * 菜单编辑二级菜单编码
	 */
	public static final String MENUCODE2 = "100101";
}

