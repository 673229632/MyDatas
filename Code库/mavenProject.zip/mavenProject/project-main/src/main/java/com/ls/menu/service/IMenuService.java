/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: IMenuService.java
 * @类路径: com.ls.menu.service
 */

package com.ls.menu.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.ls.menu.domain.Menu;
import com.ls.utils.pageUtils.PageModel;

/**
 *
 * @see		
 * @author  lyguan
 * @date	2017年7月10日 下午2:52:33
 * @version	 
 * @desc    TODO
 */
public interface IMenuService {

	/**
	 * 获得所有菜单
	 * @see
	 * @Title: getAllMenu  
	 * @author gly_ls
	 * @return     
	 * @return List<Menu>    返回类型
	 */
	List<Menu> getAllMenu();
	
	/**
	 * 获得一级菜单
	 * @see
	 * @Title: getFirstMenu  
	 * @author gly_ls
	 * @return     
	 * @return List<Menu>    返回类型
	 */
	List<Menu> getFirstMenu();
	
	/**
	 * 获得二级菜单
	 * @see
	 * @Title: getSecondMenu  
	 * @author gly_ls
	 * @return     
	 * @return List<Menu>    返回类型
	 */
	List<Menu> getSecondMenu();
	/**
	 * 菜单分页
	 * @see
	 * @Title: getMenuByPage  
	 * @author gly_ls
	 * @return     
	 * @return Page<Menu>    返回类型
	 */
	PageInfo<Menu> getMenuByPage(Menu menu, PageModel page);
	/**
	 * 根据菜单等级返回添加的菜单编码
	 * @see
	 * @Title: getAddMenuCode  
	 * @author gly_ls
	 * @param grade
	 * @param parentName
	 * @return     
	 * @return String    返回类型
	 */
	String getAddMenuCode(int grade, String parentName);
	/**
	 * 插入菜单
	 * @see
	 * @Title: addMenu  
	 * @author gly_ls
	 * @param menu
	 * @return     
	 * @return int    返回类型
	 */
	int addMenu(Menu menu);
	/**
	 * 根据id删除一个菜单
	 * @see
	 * @Title: delOneMenu  
	 * @author gly_ls
	 * @param id
	 * @return     
	 * @return int    返回类型
	 */
	int delOneMenu(String id);
	/**
	 * 批量删除菜单（加事物）
	 * @see
	 * @Title: delMoreMenu  
	 * @author gly_ls
	 * @param ids
	 * @return     
	 * @return int    返回类型
	 */
	int delMoreMenu(String[] ids);
	/**
	 * 更新菜单状态
	 * @see
	 * @Title: updateMenuFlag  
	 * @author gly_ls
	 * @param id
	 * @param flag
	 * @return     
	 * @return int    返回类型
	 */
	int updateMenuFlag(String id,String flag);
	
}

