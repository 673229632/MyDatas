/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: MenuController.java
 * @类路径: com.ls.menu
 */

package com.ls.menu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ls.menu.domain.Menu;
import com.ls.menu.service.IMenuService;
import com.ls.utils.pageUtils.PageModel;

/**
 *
 * @see		
 * @author  gly_ls
 * @date	2017年7月25日 下午8:13:21
 * @version	 
 * @desc    TODO
 */
@Controller
@RequestMapping("/web/menu")
public class MenuController {

	@Autowired
	private IMenuService menuService;
	
	/**
	 * 菜单列表显示
	 * @see
	 * @Title: initList  
	 * @author gly_ls
	 * @param model
	 * @param request
	 * @param response
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/initList")
	public String initList(Menu menu, @ModelAttribute("page")PageModel page , Model model, 
			HttpServletRequest request, HttpServletResponse response){
		PageInfo<Menu> menuPage = menuService.getMenuByPage(menu, page);
		model.addAttribute("menu", menu);
		model.addAttribute("page", menuPage);
		return "/menu/list";
	}

	/**
	 * 显示添加菜单页面
	 * @see
	 * @Title: showAddMenu  
	 * @author gly_ls
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/showAddMenu")
	public String showAddMenu(){
		return "/menu/add";
	}
	/**
	 * 添加菜单
	 * @see
	 * @Title: doAddMenu  
	 * @author gly_ls
	 * @param menu
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/doAddMenu")
	@ResponseBody
	public String doAddMenu(Menu menu,HttpServletRequest request, HttpServletResponse response){
		JSONObject returnObj = new JSONObject();
		//插入menu
		int i = menuService.addMenu(menu);
		returnObj.put("status", i);
		return returnObj.toString();
	}
	/**
	 * 通过数据库查找，自动添加menuCode
	 * @see
	 * @Title: checkMenuCode  
	 * @author gly_ls
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/addMenuCode")
	@ResponseBody
	public String checkMenuCode(int grade, String parentName){
		JSONObject returnObj = new JSONObject();
		//通过菜单等级和父级菜单获取菜单编码
		String code = menuService.getAddMenuCode(grade,parentName);
		returnObj.put("code", code);
		return returnObj.toString();
	}
	/**
	 * 删除菜单
	 * @see
	 * @Title: delMenu  
	 * @author gly_ls
	 * @param id
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/delOneMenu")
	@ResponseBody
	public String delMenu(String id){
		JSONObject returnObj = new JSONObject();
		returnObj.put("status", menuService.delOneMenu(id));
		return returnObj.toString();
	}
	
	/**
	 * 修改菜单状态
	 * @see
	 * @Title: editMenuFlag  
	 * @author gly_ls
	 * @param menuId
	 * @param flag
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/editMenuFlag")
	@ResponseBody
	public String editMenuFlag(String menuid, String flag){
		JSONObject returnObj = new JSONObject();
		if(flag != null && !"".equals(flag)){
			returnObj.put("status",menuService.updateMenuFlag(menuid, flag));
		}
		return returnObj.toString();
	}
	
	/**
	 * 批量删除菜单
	 * @see
	 * @Title: delMoreMenu  
	 * @author gly_ls
	 * @param ids
	 * @param request
	 * @param response
	 * @return     
	 * @return String    返回类型
	 */
	@RequestMapping("/delMoreMenu")
	@ResponseBody
	public String delMoreMenu(@RequestParam("menuIds[]") String[] ids,HttpServletRequest request,HttpServletResponse response){
		JSONObject returnObj = new JSONObject();
		
		return returnObj.toString();
	}
	
}

