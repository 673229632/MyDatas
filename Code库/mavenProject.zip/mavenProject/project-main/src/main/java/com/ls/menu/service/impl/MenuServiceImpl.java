/**
 * @单位名称：合肥斡亿信息科技有限公司
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：MHUB平台
 * @工程名称：project-main
 * @文件名称: MenuServiceImpl.java
 * @类路径: com.ls.menu.service.impl
 */

package com.ls.menu.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import com.ls.menu.dao.MenuMapper;
import com.ls.menu.domain.Menu;
import com.ls.menu.service.IMenuService;
import com.ls.utils.pageUtils.PageModel;

/**
 *
 * @see
 * @author lyguan
 * @date 2017年7月10日 下午2:53:39
 * @version
 * @desc TODO
 */
@Service
public class MenuServiceImpl implements IMenuService {

	/**********************
	 * 不加注释的方法是继承方法 * * *
	 **********************
	 */
	@Autowired
	private MenuMapper menuMapper;

	public List<Menu> getAllMenu() {
		return menuMapper.selectAllMenu();
	}

	public List<Menu> getFirstMenu() {
		List<Menu> firstMenu = new ArrayList<Menu>();
		for (Menu menu : getAllMenu()) {
			if (menu.getParentcode() == null || "".equals(menu.getParentcode().trim())) {
				firstMenu.add(menu);
			}
		}
		if (firstMenu != null && firstMenu.size() > 0) {
			return firstMenu;
		}
		return null;
	}

	public List<Menu> getSecondMenu() {
		List<Menu> secondMenu = new ArrayList<Menu>();
		for (Menu menu : getAllMenu()) {
			if (menu.getParentcode() != null && !"".equals(menu.getParentcode().trim())) {
				secondMenu.add(menu);
			}
		}
		if (secondMenu != null && secondMenu.size() > 0) {
			return secondMenu;
		}
		return null;
	}

	public PageInfo<Menu> getMenuByPage(Menu menu, PageModel page) {
		Page<Menu> list1 = menuMapper.selectMenuByPage(menu, page);
		PageInfo<Menu> list = new PageInfo<Menu>(list1);
		return list;
	}

	public String getAddMenuCode(int grade, String parentName) {
		List<Menu> menuList = null;
		// grade=1 一级菜单 grade=0 二级菜单
		if (grade == 0) {
			menuList = menuMapper.selectMenuByParentName(parentName);
			if (!CollectionUtils.isNotEmpty(menuList)) {
				Menu menu = new Menu();
				Menu menu1 = new Menu();
				List<Menu> parentMenu = menuMapper.selectParentName(parentName);
				if (CollectionUtils.isNotEmpty(parentMenu)) {
					menu = parentMenu.get(0);
				}
				menu1.setMenucode(menu.getMenucode() + "00");
				menuList.add(menu1);
			}
		} else if (grade == 1) {
			// 系统配置已经写好，所以不写一级菜单的判断逻辑
			menuList = getFirstMenu();
		} else {
			return null;
		}
		return checkMenuCode(menuList);
	}

	public int addMenu(Menu menu) {
		return menuMapper.insert(menu);
	}

	public int delOneMenu(String id){
		return menuMapper.deleteByPrimaryKey(id);
	}
	public int delMoreMenu(String[] ids) {
		return menuMapper.menuDelByIds(ids);
	}
	public int updateMenuFlag(String id, String flag) {
		return menuMapper.updateMenuFlag(id, flag);
	}
	
	/**
	 * 工具方法：获取code最大值+1
	 * 
	 * @see
	 * @Title: checkMenuCode
	 * @author gly_ls
	 * @param MenuList
	 * @return
	 * @return String 返回类型
	 */
	public String checkMenuCode(List<Menu> MenuList) {
		List<Integer> code = new ArrayList<Integer>();
		for (Menu menu : MenuList) {
			code.add(Integer.parseInt(menu.getMenucode()));
		}
		if (CollectionUtils.isNotEmpty(code)) {
			int max = Collections.max(code) + 1;
			return max + "";
		} else {
			return null;
		}
	}

}
