package com.ls.menu.domain;

import java.io.Serializable;

public class Menu implements Serializable{
    /**  
     * 序列化
	 * @author gly_ls
	 * @time 2017年7月22日
	*/  
	private static final long serialVersionUID = -3247924340396222818L;

	/**
     * id
     */
    private String id;

    /**
     *菜单名
     */
    private String menuname;

    /**
     *菜单编码  4位
     */
    private String menucode;

    /**
     * 菜单URL
     */
    private String menuurl;

    /**
     * 父级菜单编码
     */
    private String parentcode;

    /**
     * 图标编码
     */
    private Integer displayseq;

    /**
     * 菜单状态 0 禁止使用  1正常使用
     */
    private String flag;

    /**
     * 排序码 数字越小越靠前
     */
    private Integer sortnum;
/*========================如果添加字段，请在以下添加===========================*/
    /**
     * 菜单等级 1 一级菜单 0 二级菜单
     */
    private Integer grade ;
    
    /**
     * 父级菜单
     */
    private String parentMenu;
    
    
    
    
    
    
    /*---------------以下是get、set方法-----------------*/
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getMenuname() {
        return menuname;
    }
    public void setMenuName(String menuname) {
        this.menuname = menuname;
    }
    public String getMenucode() {
        return menucode;
    }
    public void setMenucode(String menucode) {
        this.menucode = menucode;
    }
    public String getMenuurl() {
        return menuurl;
    }
    public void setMenuurl(String menuurl) {
        this.menuurl = menuurl;
    }
    public String getParentcode() {
        return parentcode;
    }
    public void setParentcode(String parentcode) {
        this.parentcode = parentcode;
    }
    public Integer getDisplayseq() {
        return displayseq;
    }
    public void setDisplayseq(Integer displayseq) {
        this.displayseq = displayseq;
    }
    public String getFlag() {
        return flag;
    }
    public void setFlag(String flag) {
        this.flag = flag;
    }
    public Integer getSortnum() {
        return sortnum;
    }
    public void setSortnum(Integer sortnum) {
        this.sortnum = sortnum;
    }
	public Integer getGrade() {
		return grade;
	}
	public void setGrade(Integer grade) {
		this.grade = grade;
	}
	public String getParentMenu() {
		return parentMenu;
	}
	public void setParentMenu(String parentMenu) {
		this.parentMenu = parentMenu;
	}
    
}