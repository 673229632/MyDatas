package com.ls.utils.database;

/**
 *  * 空接口，用于mybatis接口实现
 * @ClassName  MybatisMapper 
 * @Description  TODO
 * @date  2016年5月27日 下午5:15:12 
 * @author memory_ls
 * @param <T>
 */
public interface MybatisMapper<T> {
}
