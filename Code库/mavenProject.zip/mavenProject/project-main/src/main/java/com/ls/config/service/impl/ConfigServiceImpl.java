/**
 * @Copyright (c) 2017 All Rights Reserved.
 * @系统名称：
 * @工程名称：project-main
 * @文件名称: ConfigServiceImpl.java
 * @类路径: com.ls.config.service.impl
 */

package com.ls.config.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ls.config.dao.SysConfigMapper;
import com.ls.config.domain.SysConfig;
import com.ls.config.service.IConfigService;

/**
 *
 * @see		
 * @author  gly_ls
 * @date	2017年7月22日 下午10:11:21
 * @version	 
 * @desc    TODO
 */
@Service
public class ConfigServiceImpl implements IConfigService {

	@Autowired
	private SysConfigMapper sysConfigMapper;
	
	public SysConfig getSysConfig() throws Exception {
		List<SysConfig> list = sysConfigMapper.selectAllConfig();
		if(list != null && list.size() > 0){
			return list.get(0);
		}else{
			return null;
		}
	}

}

