$(".Scrollbar").mCustomScrollbar(
	  	{
	  		scrollButtons:{
				enable:true,
				scrollType:"continuous",
				scrollSpeed:20,
				scrollAmount:40
			},
			theme:"minimal", //主题
		 	horizontalScroll:false,  //横向滚动条
	  	}
	  );