//菜单
var testMenu = [{
		"name": "系统配置",
		"submenu": [{
				"name": "用户配置",
				"url": "/mhubbase//web/user/initList"
			},
			{
				"name": "角色配置",
				"url": "http://localhost:8090/mhubV2/web/role/initList"
			},
			{
				"name": "菜单配置",
				"url": "http://localhost:8090/mhubV2/web/sysmenu/initMenuListPage"
			}
		]
	},
	{
		"name": "通知通告",
		"submenu": [{
			"name": "通知通告管理",
			"url": "iframe.html"
		},
		{
			"name": "通知通告查看",
			"url": "jqgridiframe.html"
		}
		]
	},
	{
		"name": "工作简报",
		"submenu": [{
				"name": "写简报",
				"url": "jqgridiframe.html"
			},
			{
				"name": "已接收",
				"url": "jqgridiframe.html"
			},
			{
				"name": "已发送",
				"url": "jqgridiframe.html"
			}
		]
	},
	{
		"name": "申请审批",
		"submenu": [{
				"name": "发起审批",
				"url": "jqgridiframe.html"
			},
			{
				"name": "我的待办",
				"url": "jqgridiframe.html"
			},
			{
				"name": "已处理任务",
				"url": "jqgridiframe.html"
			},
			{
				"name": "我的申请",
				"url": "jqgridiframe.html"
			}
		]
	},
	{
		"name": "偏好分组",
		"url": "jqgridiframe.html"
	},
	{
		"name": "部门配置",
		"url": "http://localhost:8090/mhubV2/web/dept/initList"
	}
];
$(function() {
	new AccordionMenu({
		menuArrs: testMenu
	});
});