$(function(){
    
    new WOW().init();

    $("#owl-demo").owlCarousel({
             
        autoPlay: 3000, 
        navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
        responsive:false,
        mouseDrag : false,
        items : 1,
        navigation : true
    });

    $('.header-c .btn').click(function(){
        var headerNavliLenght = $('.header-c .nav li').length;
        var timer = setInterval(function(){
            $('.header-c .nav li').eq(headerNavliLenght-1).transition({ opacity : 0, scale : 0.5});
            headerNavliLenght--;
            if(headerNavliLenght < 0){
                clearInterval(timer);
            }
        },50)
        setTimeout(function(){
            $('form').css('display','block').animate({
                'left':'375',
                'opacity':1
            },400,'swing');
            $('.speedform').css('display','block').animate({
                'opacity':1
            },'swing');
            $('.speedform-m').animate({
                'left':0,
                'opacity':375
            },'swing');
        },500);
        $('.header-c .btn').transition({ opacity: 0, scale: 0.5 },function(){
            $(this).css('display','none').transition({ scale : 1});
            $('.header-c .clo').css({
                'display':'block'
            }).animate({'opacity':1});
        });
    });
    $('.header-c .clo').click(function(){
        $('.searchform').animate({
            'left':'700',
            'opacity':0
        },100,'swing');
        $('.speedform').animate({
            'opacity':0
        }).css('display','none');
        $('.speedform-m').animate({
            'left':'700',
            'opacity':1
        },700,'swing');
        var headerNavliLenght = $('.header-c .nav li').length;
        var i = 0;
        var timer = setInterval(function(){
            $('.header-c ul.nav li').eq(i).transition({ opacity: 1, scale: 1 });
            i++;
            if(i == headerNavliLenght){
                clearInterval(timer);
            }
        },50);
        $('.header-c .clo').transition({ opacity: 0, scale: 0.5 },function(){
            $(this).css('display','none').transition({ scale : 1});
            $('.header-c .btn').css({
                'display':'block'
            }).animate({'opacity':1});
        });
    });
})