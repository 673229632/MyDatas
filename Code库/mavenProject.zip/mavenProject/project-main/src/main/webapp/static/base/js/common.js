 function conveterParamsToJson(paramsAndValues) {
	var jsonObj = {};
	if(paramsAndValues.indexOf('?')==0){
		paramsAndValues=paramsAndValues.substring(1);
	}
	if(paramsAndValues.indexOf('&')==0){
		paramsAndValues=paramsAndValues.substring(1);
	}
	paramsAndValues=decodeURIComponent(paramsAndValues,true);
	var param = paramsAndValues.split("&");
	for ( var i = 0; param != null && i < param.length; i++) {
		var para = param[i].split("=");
		jsonObj[para[0]] = para[1]||'';
	}

	return jsonObj;
}
 
/**
   * 重置表单 
   * @param formid 表单id
   * @param callback 重置回调函数
   */
  function resetForm(formid,callback){
	  // 注意：reset函数并不能重置hidden的默认值
	  document.getElementById(formid).reset();
	  // 重置chosen
	  $("#" + formid + " select[class*='chosen-select']").each(function(index, e){
		  $(e).chosen("destroy");
		  $(e).chosen({search_contains: true});
	  });
	  // 重置jqueryValidator
	  var formvalidator = $("#" + formid).data("validator");
	  if(formvalidator){
		  formvalidator.resetForm();
	  }
	  // 重置bootstrapValidaator
	  // var formvalidator = $("#" + formid).data('bootstrapValidator');
	  // if(formvalidator){
		  // formvalidator.resetForm();
	  // }
	  // 重置bootstrap-datetimepicker
	  $("#" + formid + " input[readonly='readonly']").each(function(index, e){
		  $(this).parent() && $(this).parent().data("datetimepicker") 
		  	&& $(this).parent().datetimepicker("reset");
	  });
	  if(callback){
		  callback();
	  }
  }

function queryParamByFormId(form) {
	var formValues = $("#" + form).serialize();
    //关于jquery的serialize方法转换空格为+号的解决方法
    formValues = formValues.replace(/\+/g," ");   // g表示对整个字符串中符合条件的都进行替换
	var temp = JSON.stringify(conveterParamsToJson(formValues));
	var queryParam = JSON.parse(temp);
	return queryParam;
}

function getFormDataByFormId(formid){
	 var aa= $('#'+formid).serialize(); 
     //alert(aa); // + 号显示多个
     var bb=aa;
     //关于jquery的serialize方法转换空格为+号的解决方法
     bb = aa.replace(/\+/g," ");   // g表示对整个字符串中符合条件的都进行替换
    // var cc = decodeURIComponent(bb);  //对serialize后的内容进行解码
    // alert(cc);
    return bb;
};
/**
 * js 跳转到主页
 */
function toPage(url){
	 var topWin= (function (p,c){
         while(p!=c){
             c = p        
             p = p.parent
         }
         return c
     })(window.parent,window);
	 topWin.location.href=url;
}

/*
 * 替换url 中的斜杠
 */
function replaceSep(str){
	var replaceStr = "/+";	
	//return str.replace(new RegExp(replaceStr,'gm'),'_');
	return str.replace(new RegExp('/+','gm'),'_').replace(new RegExp('\\?','gm'),'_')
		.replace(new RegExp('&','gm'),'_').replace(new RegExp('=','gm'),'_').replace(new RegExp('-','gm'),'_');
}