//layer弹框消息提醒,time为时间（毫秒单位）
function layer_message(message,time){
	layer.msg(message, {
			offset: '0px',
		  skin: 'demo-class',
		  icon: 1,
		  time: time //1秒关闭（如果不配置，默认是3秒）
	});  
}