// 分页的JS 依赖jquery.js jquery.form.js,page.css,images/table/*,images/page/*
// 查询的form的name和id 要写成queryForm
var numRegExp = /^\d*$/;
// JS触发事件函数
function onkeyupEvent(evt) {
	try {
		evt = (evt) ? evt : (window.event ? window.event : "");
		var keyCode = evt.keyCode ? evt.keyCode : evt.which;
	}
	catch (err) {
	}
	if (evt.keyCode == 13) {
		gotopage();
	} else {
	}
}
// 页面跳转的函数
function gotopage() {
	var lastPageNo = document.getElementById("totalPageCount").value;
	var pageNo = document.getElementById("pageNo").value;
	if (!numRegExp.test(pageNo)) {
		alert("\u8f93\u5165\u7684\u9875\u6570\u4e0d\u5408\u6cd5\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165\uff01");
		document.getElementById("pageNo").blur();
		return;
	} else {
		if (parseInt(pageNo) > parseInt(lastPageNo)) {
			pageNo = lastPageNo;
		}
	}
	if (pageNo <= 0) {
		pageNo = 1;
	}
	var url = document.getElementById("url").value + "&pageNo=" + pageNo;
	document.queryForm.setAttribute("action", url);
	doQuery();
}
// 排序的函数
function orderFun(columnName) {
	getObj("orderColumnName").value = columnName;
	var orderWay = getObj("orderWay").value;
	if (orderWay.length != 0) {// 如果排序方式不为空 则判断
		if (orderWay == "desc") {
			getObj("orderWay").value = "asc";
		} else {
			if (orderWay == "asc") {
				getObj("orderWay").value = "";
				getObj("orderColumnName").value = "";
			}
		}
	} else {
		getObj("orderWay").value = "desc";
	}
	var url = getObj("url").value;
	document.queryForm.setAttribute("action", url);
	doQuery();
}


function flushPage() {
	var pageNo = 1;
	try {
		pageNo = document.getElementById("pageNo").value;
		var url = document.getElementById("url").value;
		if(url.indexOf("?") != -1) {
			url += "&pageNo=" + pageNo;
		} else {
			url += "?pageNo=" + pageNo;
		}
		document.queryForm.setAttribute("action", url);
	} catch (err) {
		
	}
	document.queryForm.submit();
}

function flushParentPage() {
	var pageNo = 1;
	try {
		pageNo = window.opener.document.getElementById("pageNo").value;
		var url = window.opener.document.getElementById("url").value;
		if(url.indexOf("?") != -1) {
			url += "&pageNo=" + pageNo;
		} else {
			url += "?pageNo=" + pageNo;
		}
		window.opener.document.queryForm.setAttribute("action", url);
	} catch (err) {
		
	}
	window.opener.document.queryForm.submit();
}

function closeOpenPage() {
	window.close();
}

// 显示排序图片的函数
function showOrderImage() {
	try {
		var orderid = getObj("orderColumnName").value;
		var orderWay = getObj("orderWay").value;
		var newImg = document.createElement("img");
		if (orderid.length == 0) {
			return;
		} else {
			orderid += "_Order";
			if (orderWay.length == 0) {
				return;
			} else {
				if (orderWay == "desc") {
					newImg.src = "images/page/sortDesc.gif";
					document.getElementById(orderid).appendChild(newImg);
				} else {
					if (orderWay == "asc") {
						newImg.src = "images/page/sortAsc.gif";
						document.getElementById(orderid).appendChild(newImg);
					} else {
					// do nothing
					}
				}
			}
		}
	}
	catch (err) {
	}
}
// 操作checkbox
function checkOrCancel(curIndex) {
	var allChecks = document.getElementsByName("ifCheck");
	var length = allChecks.length;
	for (var i = 0; i < length; i++) {
		allChecks[i].checked = curIndex.checked;
	}
}

// 根据ID获取对象
function getObj(oid) {
	return document.getElementById(oid);
}

// ajax
function ajaxReq(url, obj) {
	var idStr = "";
	$("input:checked").each(function(){
		if($(this).attr("name") == "ifCheck") {
			idStr +=  $(this).val() + ",";// 可以获取值
		}
	});
	// 下面的写法不支持FF
	// $("[name='ifCheck'][checked='checked']").each(function () {
		// idStr += $(this).val() + ",";
	// });
	if (idStr.length == 0) {
		alert("请选择要删除的记录!");
		return;
	}
	if (!confirm("确定执行删除操作?")) {
		return;
	}
	idStr = idStr.substring(0, idStr.length - 1);
	url = url + "&idStr=" + idStr;
	$.ajax({type:"post", url:url, dataType:"text", cache:false, async:true, beforeSend:function (XMLHttpRequest) {
		// createAjaxDiv();
		$(obj).attr("disabled",true);
	}, success:function (data, textStatus) {
		if (data == "ok") {
			alert("删除成功");
		} else if(data == "error"){
			alert("删除失败");
		} else {
			alert("删除失败,您的权限不足");
		}
		$(obj).attr("disabled",false);
	}, complete:function (XMLHttpRequest, textStatus) {
		flushPage();
	}, error:function () {
		alert("未定义的操作");
		$(obj).attr("disabled",false);
	}});
}

function openPage(url,title,showwidth,showheight) {
	var height = showheight == null ? document.body.clientHeight : showheight;
	var width = showwidth == null ?  document.body.clientWidth : showwidth;
	var top = (screen.height-height)/2;
	var left = (screen.width-width)/2;
	var config = "width=" + width + ",height=" + height + ",status=no,scrollbars=yes,help=no,resizable=yes,top="+top+",left="+left;
	window.open(url,title,config);
	// window.location.href = url;
	return;
}

// 去掉空格
String.prototype.trim = function () {
	// 用正则表达式将前后空格
	// 用空字符串替代。
	return this.replace(/(^\s*)|(\s*$)/g, "");
};
/* 创建ajax的loader div* */
function createAjaxDiv() {
	// 以下是基于jquery的JS脚本
	var parentDiv = $("<div></div>");
	parentDiv.attr("id", "ajaxDiv");
	parentDiv.addClass("ajaxDiv");
	var newImg = $("<img />");
	newImg.appendTo(parentDiv);
	parentDiv.appendTo("body");
	// 以下是JS脚本
	// var newDiv = document.createElement("DIV");
	// newDiv.id = "ajaxDiv";
	// newDiv.className = "ajaxDiv";
	// var newImg = document.createElement("IMG");
	// newDiv.appendChild(newImg);
	// document.body.appendChild(newDiv);
}
function removeDiv() {
	$("#ajaxDiv").remove();
}

// 两个参数，一个是cookie的名子，一个是值
function SetCookie(name, value) {
	var Days = 30; // 此 cookie 将被保存 30 天
	var exp = new Date();    // new Date("December 31, 9998");
	exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
}
// 读取cookies函数
function getCookie(name) {
	var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if (arr != null) {
		return unescape(arr[2]);
	}
	return null;
}
// 删除cookie
function delCookie(name) {
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval = getCookie(name);
	if (cval != null) {
		document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
	}
}

// ajax 查询提交
function doQuery() {
	$("#queryForm").ajaxSubmit({beforeSubmit:function () {
	}, success:function (data) {
		document.open();
		document.write(data);
		document.close();
		showOrderImage();
	}, error:function () {
		alert("未定义的操作");
	}
	});
}
function doQueryAfterGoBack() {
	if (getCookie("isBack") == "true") {// 说明是BACK回来的
		delCookie("isBack");
		doQueryAfterEdit();
	} else {
	}
}
function goBack() {
	SetCookie("isBack", "true");
	history.go(-1);
}

// 编辑,增加或者返回后 ajax查询提交
function doQueryAfterEdit() {
	var pageNo = document.getElementById("pageNo").value;
	var url = document.getElementById("url").value + "&pageNo=" + pageNo;
	document.queryForm.setAttribute("action", url);
	$("#queryForm").ajaxSubmit({beforeSubmit:function () {
	}, success:function (data) {
		document.open();
		document.write(data);
		document.close();
		showOrderImage();
	}});
}

function goHome(url) {
	//window.top.indexFrame.location.href = url;
	window.location = url;
}

function senfe(o,a,b,c){
 if (document.getElementById(o) != null) {
	 var t=document.getElementById(o).getElementsByTagName("tr");
	 for(var i=0;i<t.length;i++){
	  t[i].style.backgroundColor=(t[i].sectionRowIndex%2==0)?a:b;
	  
	  t[i].onmouseover=function(){
	   if(this.x!="1")this.style.backgroundColor=c;
	  }
	  t[i].onmouseout=function(){
	   if(this.x!="1")this.style.backgroundColor=(this.sectionRowIndex%2==0)?a:b;
	  }
	 } 
 }
}

function openYmtWin(url, title,showwidth,showheight) {
	try {
		ymPrompt.close();
	} catch(err) {
		//alert(err);
	}
	ymPrompt.setDefaultCfg({title:'Default Title', message:"Default Message",okTxt:'确认 ',cancelTxt:' 取消 ',closeTxt:'关闭',minTxt:'最小化',maxTxt:'最大化'});
	var width = (showwidth == null ? document.body.clientWidth : showwidth)- 40;
	var height = (showheight == null ? document.documentElement.clientHeight : showheight) - 40;
	ymPrompt.win({message:url, width:width, height:height, title:title, handler:handler, maxBtn:true, minBtn:true, iframe:true,showMask:false});
}

function handler(tp){
	if(tp=='close'){
		//maskLevel
		//ym-window
		//ym-shadow
		//$("#maskLevel").remove();
		//$("#ym-window").remove();
		//$("#ym-shadow").remove();
		//window.parent.ymPrompt.close();
		//alert("");
	}
}

function flushYmtParentPage() {
	/*var pageNo = 1;
	try {
		pageNo = window.parent.document.getElementById("pageNo").value;
		var url = window.parent.document.getElementById("url").value;
		if(url.indexOf("?") != -1) {
			url += "&pageNo=" + pageNo;
		} else {
			url += "?pageNo=" + pageNo;
		}
		window.parent.document.queryForm.setAttribute("action", url);
	} catch (err) {
		
	}*/
	//window.parent.document.queryForm.submit();
	$("#btnQuery",window.parent.document).click();
}

function closeYmtPage() {
	window.parent.ymPrompt.close();
	window.location.reload();
}

function doDeleteExtRecored(url,obj){
	if (!confirm("确定执行删除操作？")) {
		return;
	}
	url+="&t="+(new Date()).valueOf();
    $.ajax({type:"post", url:url, dataType:"text", cache:false, async:true, beforeSend:function (XMLHttpRequest) {
    	if(obj!=null)
		$(obj).attr("disabled",true);
	}, success:function (data, textStatus) {
		if (data == "ok") {
			alert("删除成功！");
		} else if(data == "error"){
			alert("删除失败！");
		} else {
			alert("删除失败，您的权限不足！");
		}
		if(obj!=null)
		$(obj).attr("disabled",false);
	}, complete:function (XMLHttpRequest, textStatus) {
		$("#btnQuery").click();
	}, error:function () {
		alert("未定义的操作！");
		if(obj!=null)
		$(obj).attr("disabled",false);
	}});
}