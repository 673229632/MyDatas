 function AccordionMenu(options) {
	this.config = {
		baseUrl             : '',                
		containerCls        : '.wrap-menu',                
		menuArrs            :  '',                         
		type                :  'click',                    
		renderCallBack      :  null,                       
		clickItemCallBack   : this._addItem                        
	};
	this.cache = {
		
	};
	this.init(options);
 }

 //验证url
 function _isURL(domain) {  
    var name = /[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/;  
    if( !(name.test(domain))){  
        return false;  
    }else{  
        return true;  
    }  
}  
 
 AccordionMenu.prototype = {

	constructor: AccordionMenu,

	init: function(options){
		this.config = $.extend(this.config,options || {});
		var self = this,
			_config = self.config,
			_cache = self.cache;
		
		$(_config.containerCls).each(function(index,item){
			
			self._renderHTML(item);

			self._bindEnv(item);
		});
	},
	_renderHTML: function(container){
		var self = this,
			_config = self.config,
			_cache = self.cache;
			_cache = self.cache;
		var ulhtml = $('<ul></ul>');
		$(_config.menuArrs).each(function(index,item){
			var url = item.url || '';
			if(url != '' && item.opentype != 3){ //0：frame打开，1：layer打开，2：openwindow，3:新选项卡打开
				if( _config != undefined && !_isURL(url)){
					url = _config.baseUrl + url;
				}
			}
			//父菜单
			var lihtml = $('<li><a href="javascript:void(0)" opentype="'
					+ item.opentype + '"  dataUrl="' + url + '">'
					+ item.name + '<b><img src="'
					+ _config.baseUrl
					+ ((item.icon == '' || item.icon == null) ? '/static/base/images/menu_ico.png' : '/web/file/showPicById?id='+ item.icon +'&isThumbnail=false')
					+ '" /></b><i></i></a></li>');

			if(item.submenu && item.submenu.length > 0) {
				self._createSubMenu(item.submenu,lihtml);
			}
			$(ulhtml).append(lihtml);
		});
		$(container).append(ulhtml);
		
		_config.renderCallBack && $.isFunction(_config.renderCallBack) && _config.renderCallBack();
		
		self._levelIndent(ulhtml);
	},
	_createSubMenu: function(submenu,lihtml){
		var self = this,
			_config = self.config,
			_cache = self.cache;
		var subUl = $('<ul></ul>'),
			callee = arguments.callee,
			subLi;
		
		$(submenu).each(function(index,item){
			var url = item.url || '';
			if(url != '' && item.opentype != 3){ //0：frame打开，1：layer打开，2：openwindow，3:新选项卡打开
				if( _config != undefined && !_isURL(url)){
					url = _config.baseUrl + url;
				}
			}
			subLi = $('<li><a href="javascript:void(0)" opentype="'+item.opentype+'" dataUrl="'+url+'">'+item.name+'</a></li>');
			if(item.submenu && item.submenu.length > 0) {
				$(subLi).children('a').prepend('');
                callee(item.submenu, subLi);
			}
			$(subUl).append(subLi);
		});
		$(lihtml).append(subUl);
	},
	_levelIndent: function(ulList){
		var self = this,
			_config = self.config,
			_cache = self.cache,
			callee = arguments.callee;
	   
		var initTextIndent = 0,
			lev = 1,
			$oUl = $(ulList);
		
		while($oUl.find('ul').length > 0){
			initTextIndent = parseInt(initTextIndent,10) ; 
			$oUl.children().children('ul').addClass('lev-' + lev)
						.children('li').css('text-indent', initTextIndent);
			$oUl = $oUl.children().children('ul');
			lev++;
		}
		$(ulList).find('ul').hide();
		//$(ulList).find('ul:first').show();	
	},
	_bindEnv: function(container) {
		var self = this,
			_config = self.config;
		$('h2,a',container).unbind(_config.type);
		$('h2,a',container).bind(_config.type,function(e){
			if($(this).siblings('ul').length > 0) {
				$(this).siblings('ul').slideToggle('fast').end().children('img').toggleClass('unfold');
			}

			$(this).parent('li').siblings().find('ul').hide()
				   .end().find('img.unfold').removeClass('unfold');
				   $(".wrap-menu .active").removeClass('active');
				   $(this).addClass('active');
			_config.clickItemCallBack && $.isFunction(_config.clickItemCallBack) && _config.clickItemCallBack($(this));

		});
	},
	_addItem:function(obj){
		var self = this
		var title = $(obj).text();
		var url = $(obj).attr("dataUrl");
		if(url != ''  && url != undefined){
			switch (obj.attr('opentype')) {
				case '0': //frame
					addTab(title,url);
					break;
				case '1': //layer
					layer.open({
						type: 2,
					    title: title,
					    scrollbar: true,
						shadeClose: true,
					    area: ['800px', '600px'],	
					    content: url
					});
					break;
				case '2': //openwindow
					var iWidth='800',iHeight='450';
					var iTop = (window.screen.height-30-iHeight)/2; 
					var iLeft = (window.screen.width-10-iWidth)/2; 
					window.open(url,title,'height='+iHeight+',,innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=auto,resizeable=no,location=no,status=no');
					break;
				case '3': //新的选项卡
					window.open(url, title);
					break;
			}
		}
	}	
 };
