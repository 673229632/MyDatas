//自动加载验证码
$(function(){
	refresh();
	$("#captchaImg").click(function(){
		refresh();
	});
});
function refresh(){
	 $("#captchaImg").attr("src", './captcha?t=' + new Date().getTime());
	 // 设置背景图片
	 $("#captchaImg")
	 	.css("background-image", "url('static/images/captcha/captcha_bg_"+Math.floor(Math.random()*39)+".jpg')")
	 	.css("background-size", "cover")
	 	.css("background-repeat", "no-repeat");
};

//登录提交校验
function submit(){
	//判断姓名、密码、验证码是否为空 
	var username = $("#username").val();
	var password = $("#password").val();
	var captcha = $("#captcha").val();
    if(username == ""){  
    	$("#errors").html("用户名为空");
        refresh();
        return;  
    };  
    
    if(password ==""){  
    	$("#errors").html("密码为空");  
        refresh();
        return;  
    }; 
    
    if(captcha==""){  
    	$("#errors").html("验证码为空"); 
        refresh();
        return;  
    };
	
    $.ajax({
    	type : "POST",
    	url : "./doLogin",
    	dataType : "json",
    	data : {username:username, password:password, captcha:captcha},
    	success : function(json){
   		var data = json;
   		if(data.status == 1){
   				location.href = "./index";
    		}else{
    			debugger;
    			var err = data.msg;
    			$("#errors").html(err); 
    			refresh();
    			$("#captcha").val("");
    		}
    	}
    });
};

//回车登录
document.onkeydown = function (event) {
    var e = event || window.event || arguments.callee.caller.arguments[0];
    if (e && e.keyCode == 13) {
    	submit();
    }
};