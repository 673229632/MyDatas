;(function($){
	$.fn.extend({
		// //(存放分页栏的DIV的ID,存放表格的类名,每页显示的条目数量,总页数,总记录,开始行，结束行，当前页码)
		"PaginBar":function(divId,table,show_per_page,pages,total,startRow,endRow,curPage){
			divId = $("#"+divId+""),tableId = $("."+table+""); 
			var number_of_items = tableId.find("tr").length;
			var number_of_pages = pages;
			var index_of_pages = number_of_pages-1;
			var start = 1;
			var totalPages = pages;
			
			var current_link = 0;
			var navigation_html = '<a class="previous_link" href="javascript:go_to_page(1);go_first();"><div id="first_page"> </div></a><a class="previous_link" href="javascript:previous();"><div> </div></a>';
			navigation_html += '<input type="text" class="num_box" longdesc="' + curPage +'" value="'+curPage+'">';
			navigation_html += '<span class="page_span" id="page_span">共 ' + totalPages +'页</span>';
			navigation_html += '<a class="next_link" href="javascript:void(0)"><div> </div></a><a class="next_link" href="javascript:go_to_page(' + totalPages +');go_last();"><div id="last_page"> </div></a>';
			if("10" == show_per_page){
				navigation_html += '<select class="perPage" onchange=changePerPage()><option value=10 selected = "selected">10&nbsp;&nbsp;&nbsp;&nbsp;</option><option value=15>15</option><option value=20>20</option></select>';
			}else if("15" == show_per_page){
				navigation_html += '<select class="perPage" onchange=changePerPage()><option value=10 >10&nbsp;&nbsp;&nbsp;&nbsp;</option><option value=15 selected = "selected">15</option><option value=20>20</option></select>';
			}else if("20" == show_per_page){
				navigation_html += '<select class="perPage" onchange=changePerPage()><option value=10 >10&nbsp;&nbsp;&nbsp;&nbsp;</option><option value=15>15</option><option value=20 selected = "selected">20</option></select>';
			}
			navigation_html += '<b id="pageInfo" align="right">'+startRow+'-'+endRow+'   共'+total+'条</b>';
			
			
			previous = function(){
				
				current_link=$(".num_box").val();
				new_page = current_link;
				if(new_page>1){
					go_to_page(parseInt(new_page)-1);
					current_link = current_link-1;
					$(".num_box").val(parseInt($(".num_box").val())-1)
				}
								
			},
			next =function(){
				current_link=$(".num_box").val();
				new_page = current_link;
				if(new_page<number_of_pages){
					go_to_page(parseInt(new_page)+1);
					current_link = current_link+1;
					$(".num_box").val(parseInt($(".num_box").val())+1)
				}
			},
			changePerPage = function(){
				$(".num_box").val(1);
				go_to_page(1);
			}
			
			getLocalTime = function(nS){
				return new Date(parseInt(nS) * 1000).toLocaleString().split(" ")[0].replace("\/","-").replace("\/","-");
			}
			
			
			go_to_page = function(page_num){
				if(!("" == page_num)){
					var perPage = $(".perPage").val();
					$("#pageNo").val(page_num);
					$("#pageSize").val(perPage);				
		        	$('#form').submit();
		    		document.getElementById("page_span").innerHTML="共 "+totalPages+"页";
		    		document.getElementById("pageInfo").innerHTML=startRow + "-" + endRow + "  共" +total + "条"; 
		    		number_of_pages = pages;
		    		totalPages = pages;
				}
				
	}			
			

			go_first = function(){
				$(".num_box").val(1);
			},
			go_last = function(){
				$(".num_box").val(number_of_pages);
			};
			
			$(divId).html(navigation_html);

			$(tableId).find("tr");
			$(tableId).find("tr").slice(0, show_per_page).css({
				"display": "table-row",
				"width":"100%;"});	
			
			$(".previous_link div,.next_link div").css({
				"width":"16px","height":"16px",
				"background":"url(../../static/images/pagination_icons.png) no-repeat",
				"display":"inline-block",
				"background-position":"-16px 3px"
			});

			$(".next_link div").css({"background-position":"-32px 3px"});
			$("#first_page").css({"background-position":"0 3px"});
			$("#last_page").css({"background-position":"-48px 3px"});
			$(".next_link").click(function(){
				next();
			})
			$(document).ready(function(){
			$(".num_box").on({
				"keydown":function(e){
					var key = e.which;
					var will_num = $(this).val();
					var max_page = number_of_pages;
					if(key == 13) {
						e.preventDefault();
						if(will_num>max_page){
							go_to_page(max_page);
							$(this).val(max_page+1)
						}else{	
							go_to_page(will_num)
						};
					}
				},
				"click":function(){
					$(this).css({"border":"1px solid #8bade4"})
				},
				"blur":function(){
					$(this).css({"border":"1px solid #cccccc"})
				}
			})	
			
			
			
		})
		} //主函数
	});//fn
}(jQuery));